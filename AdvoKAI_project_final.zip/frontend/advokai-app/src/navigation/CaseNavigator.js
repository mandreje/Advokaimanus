import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { useTheme } from '../utils/ThemeContext';
import { useLanguage, getTranslation } from '../i18n/LanguageContext';

// Import screens
import CaseListScreen from '../screens/case/CaseListScreen';
import CaseDetailScreen from '../screens/case/CaseDetailScreen';
import CaseCreateScreen from '../screens/case/CaseCreateScreen';

const Stack = createStackNavigator();

const CaseNavigator = () => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.background,
          borderBottomColor: theme.border,
          borderBottomWidth: 1,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        cardStyle: {
          backgroundColor: theme.background,
        },
      }}
    >
      <Stack.Screen
        name="CaseList"
        component={CaseListScreen}
        options={{ title: t('cases') }}
      />
      <Stack.Screen
        name="CaseDetail"
        component={CaseDetailScreen}
        options={({ route }) => ({ title: route.params?.title || t('case') })}
      />
      <Stack.Screen
        name="CaseCreate"
        component={CaseCreateScreen}
        options={{ title: t('newCase') }}
      />
    </Stack.Navigator>
  );
};

export default CaseNavigator;
