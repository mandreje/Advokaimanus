import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { useTheme } from '../utils/ThemeContext';
import { useLanguage, getTranslation } from '../i18n/LanguageContext';

// Import screens
import LawSearchScreen from '../screens/lawsearch/LawSearchScreen';
import LawResultsScreen from '../screens/lawsearch/LawResultsScreen';
import LawDetailScreen from '../screens/lawsearch/LawDetailScreen';

const Stack = createStackNavigator();

const LawSearchNavigator = () => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.background,
          borderBottomColor: theme.border,
          borderBottomWidth: 1,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        cardStyle: {
          backgroundColor: theme.background,
        },
      }}
    >
      <Stack.Screen
        name="LawSearch"
        component={LawSearchScreen}
        options={{ title: t('lawSearch') }}
      />
      <Stack.Screen
        name="LawResults"
        component={LawResultsScreen}
        options={{ title: t('search') + ' ' + t('results') }}
      />
      <Stack.Screen
        name="LawDetail"
        component={LawDetailScreen}
        options={({ route }) => ({ title: route.params?.title || t('law') })}
      />
    </Stack.Navigator>
  );
};

export default LawSearchNavigator;
