import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { useTheme } from '../utils/ThemeContext';
import { useLanguage, getTranslation } from '../i18n/LanguageContext';

// Import screens
import DocumentListScreen from '../screens/document/DocumentListScreen';
import DocumentGeneratorScreen from '../screens/document/DocumentGeneratorScreen';
import DocumentViewScreen from '../screens/document/DocumentViewScreen';
import DocumentAnalysisScreen from '../screens/document/DocumentAnalysisScreen';

const Stack = createStackNavigator();

const DocumentNavigator = () => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.background,
          borderBottomColor: theme.border,
          borderBottomWidth: 1,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        cardStyle: {
          backgroundColor: theme.background,
        },
      }}
    >
      <Stack.Screen
        name="DocumentList"
        component={DocumentListScreen}
        options={{ title: t('documents') }}
      />
      <Stack.Screen
        name="DocumentGenerator"
        component={DocumentGeneratorScreen}
        options={{ title: t('createFromDescription') }}
      />
      <Stack.Screen
        name="DocumentView"
        component={DocumentViewScreen}
        options={({ route }) => ({ title: route.params?.title || t('document') })}
      />
      <Stack.Screen
        name="DocumentAnalysis"
        component={DocumentAnalysisScreen}
        options={{ title: t('analyzeDocument') }}
      />
    </Stack.Navigator>
  );
};

export default DocumentNavigator;
