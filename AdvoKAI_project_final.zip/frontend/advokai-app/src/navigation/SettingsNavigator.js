import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { useTheme } from '../utils/ThemeContext';
import { useLanguage, getTranslation } from '../i18n/LanguageContext';

// Import screens
import SettingsScreen from '../screens/settings/SettingsScreen';
import ProfileScreen from '../screens/settings/ProfileScreen';
import TokensScreen from '../screens/settings/TokensScreen';
import JurisdictionScreen from '../screens/settings/JurisdictionScreen';
import LanguageScreen from '../screens/settings/LanguageScreen';
import AboutScreen from '../screens/settings/AboutScreen';

const Stack = createStackNavigator();

const SettingsNavigator = () => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.background,
          borderBottomColor: theme.border,
          borderBottomWidth: 1,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        cardStyle: {
          backgroundColor: theme.background,
        },
      }}
    >
      <Stack.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ title: t('settings') }}
      />
      <Stack.Screen
        name="Profile"
        component={ProfileScreen}
        options={{ title: t('profile') }}
      />
      <Stack.Screen
        name="Tokens"
        component={TokensScreen}
        options={{ title: t('tokens') }}
      />
      <Stack.Screen
        name="Jurisdiction"
        component={JurisdictionScreen}
        options={{ title: t('jurisdiction') }}
      />
      <Stack.Screen
        name="Language"
        component={LanguageScreen}
        options={{ title: t('language') }}
      />
      <Stack.Screen
        name="About"
        component={AboutScreen}
        options={{ title: t('about') }}
      />
    </Stack.Navigator>
  );
};

export default SettingsNavigator;
