import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { useTheme } from '../utils/ThemeContext';
import { useLanguage, getTranslation } from '../i18n/LanguageContext';

// Import screens
import ChatListScreen from '../screens/chat/ChatListScreen';
import ChatConversationScreen from '../screens/chat/ChatConversationScreen';

const Stack = createStackNavigator();

const ChatNavigator = () => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: theme.background,
          borderBottomColor: theme.border,
          borderBottomWidth: 1,
        },
        headerTintColor: theme.text,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        cardStyle: {
          backgroundColor: theme.background,
        },
      }}
    >
      <Stack.Screen
        name="ChatList"
        component={ChatListScreen}
        options={{ title: t('chat') }}
      />
      <Stack.Screen
        name="ChatConversation"
        component={ChatConversationScreen}
        options={({ route }) => ({ title: route.params?.title || t('chat') })}
      />
    </Stack.Navigator>
  );
};

export default ChatNavigator;
