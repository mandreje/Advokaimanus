import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const CaseListScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchCases();
  }, []);

  const fetchCases = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('cases')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      
      setCases(data || []);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const createNewCase = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('cases')
        .insert([
          { 
            user_id: user.id,
            title: t('newCase'),
            status: 'open',
            description: '',
          }
        ])
        .select();

      if (error) throw error;
      
      if (data && data.length > 0) {
        navigation.navigate('CaseDetail', { 
          caseId: data[0].id,
          title: data[0].title
        });
      }
    } catch (error) {
      setError(error.message);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'open':
        return theme.primary;
      case 'in_progress':
        return theme.warning;
      case 'closed':
        return theme.success;
      default:
        return theme.text + '60';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'open':
        return t('open');
      case 'in_progress':
        return t('inProgress');
      case 'closed':
        return t('closed');
      default:
        return status;
    }
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.caseItem}
      onPress={() => navigation.navigate('CaseDetail', { 
        caseId: item.id,
        title: item.title
      })}
    >
      <View style={styles.caseIcon}>
        <Ionicons name="briefcase-outline" size={24} color={theme.primary} />
      </View>
      <View style={styles.caseInfo}>
        <Text style={styles.caseTitle}>{item.title}</Text>
        <Text style={styles.caseDescription} numberOfLines={1}>
          {item.description || t('noDescription')}
        </Text>
        <View style={styles.caseMetaContainer}>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) + '20', borderColor: getStatusColor(item.status) }]}>
            <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
              {getStatusText(item.status)}
            </Text>
          </View>
          {item.deadline && (
            <View style={styles.deadlineContainer}>
              <Ionicons name="calendar-outline" size={14} color={theme.text + '60'} />
              <Text style={styles.deadlineText}>
                {new Date(item.deadline).toLocaleDateString()}
              </Text>
            </View>
          )}
        </View>
      </View>
      <Text style={styles.caseDate}>
        {new Date(item.updated_at).toLocaleDateString()}
      </Text>
    </TouchableOpacity>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    caseItem: {
      flexDirection: 'row',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
      alignItems: 'center',
    },
    caseIcon: {
      width: 50,
      height: 50,
      borderRadius: 25,
      backgroundColor: theme.card,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 15,
    },
    caseInfo: {
      flex: 1,
    },
    caseTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 5,
    },
    caseDescription: {
      fontSize: 14,
      color: theme.text + '80',
      marginBottom: 5,
    },
    caseMetaContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    statusBadge: {
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 12,
      borderWidth: 1,
      marginRight: 10,
    },
    statusText: {
      fontSize: 12,
      fontWeight: 'bold',
    },
    deadlineContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    deadlineText: {
      fontSize: 12,
      color: theme.text + '60',
      marginLeft: 3,
    },
    caseDate: {
      fontSize: 12,
      color: theme.text + '60',
    },
    fab: {
      position: 'absolute',
      width: 60,
      height: 60,
      borderRadius: 30,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
      right: 20,
      bottom: 20,
      elevation: 5,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 3,
    },
    fabIcon: {
      color: 'white',
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 20,
    },
    emptyText: {
      fontSize: 16,
      color: theme.text + '80',
      textAlign: 'center',
      marginTop: 10,
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      
      {cases.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="briefcase-outline" size={60} color={theme.text + '40'} />
          <Text style={styles.emptyText}>{t('noCasesYet')}</Text>
          <Text style={styles.emptyText}>{t('createNewCase')}</Text>
        </View>
      ) : (
        <FlatList
          data={cases}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={{ flexGrow: 1 }}
        />
      )}
      
      <TouchableOpacity style={styles.fab} onPress={createNewCase}>
        <Ionicons name="add" size={30} style={styles.fabIcon} />
      </TouchableOpacity>
    </View>
  );
};

export default CaseListScreen;
