import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, ActivityIndicator, FlatList, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const CaseDetailScreen = ({ route, navigation }) => {
  const { caseId, title } = route.params;
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [caseData, setCaseData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedDescription, setEditedDescription] = useState('');
  const [editedStatus, setEditedStatus] = useState('');
  const [editedDeadline, setEditedDeadline] = useState('');
  const [documents, setDocuments] = useState([]);
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState('');
  const [addingNote, setAddingNote] = useState(false);

  useEffect(() => {
    navigation.setOptions({
      title: title,
      headerRight: () => (
        <TouchableOpacity 
          style={{ marginRight: 15 }}
          onPress={() => setEditMode(!editMode)}
        >
          <Ionicons 
            name={editMode ? "save-outline" : "create-outline"} 
            size={24} 
            color={theme.text} 
          />
        </TouchableOpacity>
      ),
    });
    
    fetchCaseDetails();
    fetchCaseDocuments();
    fetchCaseNotes();
  }, [caseId]);

  useEffect(() => {
    if (caseData) {
      setEditedTitle(caseData.title);
      setEditedDescription(caseData.description || '');
      setEditedStatus(caseData.status);
      setEditedDeadline(caseData.deadline || '');
    }
  }, [caseData]);

  const fetchCaseDetails = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('cases')
        .select('*')
        .eq('id', caseId)
        .single();

      if (error) throw error;
      
      setCaseData(data);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchCaseDocuments = async () => {
    try {
      const { data, error } = await supabase
        .from('case_documents')
        .select('*, document:document_id(*)')
        .eq('case_id', caseId);

      if (error) throw error;
      
      setDocuments(data || []);
    } catch (error) {
      setError(error.message);
    }
  };

  const fetchCaseNotes = async () => {
    try {
      const { data, error } = await supabase
        .from('case_notes')
        .select('*')
        .eq('case_id', caseId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setNotes(data || []);
    } catch (error) {
      setError(error.message);
    }
  };

  const saveChanges = async () => {
    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('cases')
        .update({ 
          title: editedTitle,
          description: editedDescription,
          status: editedStatus,
          deadline: editedDeadline,
          updated_at: new Date().toISOString()
        })
        .eq('id', caseId);

      if (error) throw error;
      
      setEditMode(false);
      fetchCaseDetails();
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };

  const addNote = async () => {
    if (newNote.trim() === '') return;
    
    try {
      setAddingNote(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('case_notes')
        .insert([
          { 
            case_id: caseId,
            user_id: user.id,
            content: newNote.trim(),
          }
        ]);

      if (error) throw error;
      
      setNewNote('');
      fetchCaseNotes();
    } catch (error) {
      setError(error.message);
    } finally {
      setAddingNote(false);
    }
  };

  const attachDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true
      });
      
      if (result.canceled) return;
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      // In a real app, this would upload the document to storage
      // and create a new document record, then link it to the case
      
      // For now, we'll simulate creating a document and linking it
      
      const { data: docData, error: docError } = await supabase
        .from('documents')
        .insert([
          { 
            user_id: user.id,
            title: result.assets[0].name,
            content: 'Document content would be here',
            document_type: 'Case Document',
            security_score: 85,
            is_signed: false,
          }
        ])
        .select();

      if (docError) throw docError;
      
      if (docData && docData.length > 0) {
        const { error: linkError } = await supabase
          .from('case_documents')
          .insert([
            { 
              case_id: caseId,
              document_id: docData[0].id,
            }
          ]);
          
        if (linkError) throw linkError;
        
        fetchCaseDocuments();
      }
    } catch (error) {
      setError(error.message);
    }
  };

  const deleteCase = async () => {
    Alert.alert(
      t('deleteCase'),
      t('deleteCaseConfirmation'),
      [
        {
          text: t('cancel'),
          style: 'cancel',
        },
        {
          text: t('delete'),
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              
              // Delete case notes
              await supabase
                .from('case_notes')
                .delete()
                .eq('case_id', caseId);
                
              // Unlink documents (but don't delete them)
              await supabase
                .from('case_documents')
                .delete()
                .eq('case_id', caseId);
              
              // Delete the case
              const { error } = await supabase
                .from('cases')
                .delete()
                .eq('id', caseId);

              if (error) throw error;
              
              navigation.goBack();
            } catch (error) {
              setError(error.message);
              setLoading(false);
            }
          },
        },
      ],
    );
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'open':
        return theme.primary;
      case 'in_progress':
        return theme.warning;
      case 'closed':
        return theme.success;
      default:
        return theme.text + '60';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'open':
        return t('open');
      case 'in_progress':
        return t('inProgress');
      case 'closed':
        return t('closed');
      default:
        return status;
    }
  };

  const renderDocumentItem = ({ item }) => (
    <TouchableOpacity
      style={styles.documentItem}
      onPress={() => navigation.navigate('DocumentView', { 
        documentId: item.document.id,
        title: item.document.title
      })}
    >
      <Ionicons name="document-text-outline" size={24} color={theme.primary} />
      <View style={styles.documentInfo}>
        <Text style={styles.documentTitle}>{item.document.title}</Text>
        <Text style={styles.documentType}>{item.document.document_type}</Text>
      </View>
      <Ionicons name="chevron-forward" size={24} color={theme.text + '60'} />
    </TouchableOpacity>
  );

  const renderNoteItem = ({ item }) => (
    <View style={styles.noteItem}>
      <View style={styles.noteHeader}>
        <Ionicons name="chatbubble-outline" size={20} color={theme.primary} />
        <Text style={styles.noteDate}>
          {new Date(item.created_at).toLocaleString()}
        </Text>
      </View>
      <Text style={styles.noteContent}>{item.content}</Text>
    </View>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    content: {
      padding: 15,
    },
    section: {
      marginBottom: 20,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 10,
    },
    infoContainer: {
      backgroundColor: theme.card,
      borderRadius: 5,
      padding: 15,
      marginBottom: 20,
    },
    label: {
      fontSize: 14,
      color: theme.text + '80',
      marginBottom: 5,
    },
    value: {
      fontSize: 16,
      color: theme.text,
      marginBottom: 15,
    },
    input: {
      fontSize: 16,
      color: theme.text,
      backgroundColor: theme.background,
      borderRadius: 5,
      padding: 10,
      marginBottom: 15,
      borderWidth: 1,
      borderColor: theme.border,
    },
    textArea: {
      height: 100,
      textAlignVertical: 'top',
    },
    statusContainer: {
      flexDirection: 'row',
      marginBottom: 15,
    },
    statusButton: {
      flex: 1,
      padding: 10,
      borderWidth: 1,
      borderColor: theme.border,
      alignItems: 'center',
    },
    statusButtonFirst: {
      borderTopLeftRadius: 5,
      borderBottomLeftRadius: 5,
    },
    statusButtonLast: {
      borderTopRightRadius: 5,
      borderBottomRightRadius: 5,
    },
    selectedStatusButton: {
      borderColor: theme.primary,
      backgroundColor: theme.primary + '20',
    },
    statusText: {
      color: theme.text,
    },
    selectedStatusText: {
      color: theme.primary,
      fontWeight: 'bold',
    },
    statusBadge: {
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 15,
      alignSelf: 'flex-start',
      marginBottom: 15,
    },
    statusBadgeText: {
      fontSize: 14,
      fontWeight: 'bold',
    },
    documentsContainer: {
      marginBottom: 20,
    },
    documentItem: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      padding: 15,
      borderRadius: 5,
      marginBottom: 10,
    },
    documentInfo: {
      flex: 1,
      marginLeft: 10,
    },
    documentTitle: {
      fontSize: 16,
      color: theme.text,
      marginBottom: 5,
    },
    documentType: {
      fontSize: 14,
      color: theme.text + '80',
    },
    addButton: {
      backgroundColor: theme.primary,
      padding: 15,
      borderRadius: 5,
      alignItems: 'center',
      marginTop: 10,
      flexDirection: 'row',
      justifyContent: 'center',
    },
    addButtonText: {
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
      marginLeft: 10,
    },
    notesContainer: {
      marginBottom: 20,
    },
    noteItem: {
      backgroundColor: theme.card,
      padding: 15,
      borderRadius: 5,
      marginBottom: 10,
    },
    noteHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 5,
    },
    noteDate: {
      fontSize: 12,
      color: theme.text + '60',
      marginLeft: 5,
    },
    noteContent: {
      fontSize: 14,
      color: theme.text,
      lineHeight: 20,
    },
    addNoteContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 10,
    },
    noteInput: {
      flex: 1,
      backgroundColor: theme.card,
      borderRadius: 20,
      paddingHorizontal: 15,
      paddingVertical: 10,
      marginRight: 10,
      color: theme.text,
    },
    sendButton: {
      width: 44,
      height: 44,
      borderRadius: 22,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
    },
    deleteButton: {
      backgroundColor: theme.error,
      padding: 15,
      borderRadius: 5,
      alignItems: 'center',
      marginTop: 20,
      flexDirection: 'row',
      justifyContent: 'center',
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });

  if (loading && !caseData) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (!caseData) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 20 }]}>
        <Text style={{ color: theme.text, textAlign: 'center' }}>
          {error || t('caseNotFound')}
        </Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        
        <View style={styles.infoContainer}>
          {editMode ? (
            <>
              <Text style={styles.label}>{t('title')}</Text>
              <TextInput
                style={styles.input}
                value={editedTitle}
                onChangeText={setEditedTitle}
                placeholder={t('enterTitle')}
                placeholderTextColor={theme.text + '60'}
              />
              
              <Text style={styles.label}>{t('description')}</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={editedDescription}
                onChangeText={setEditedDescription}
                placeholder={t('enterDescription')}
                placeholderTextColor={theme.text + '60'}
                multiline
                numberOfLines={4}
              />
              
              <Text style={styles.label}>{t('status')}</Text>
              <View style={styles.statusContainer}>
                <TouchableOpacity
                  style={[
                    styles.statusButton,
                    styles.statusButtonFirst,
                    editedStatus === 'open' && styles.selectedStatusButton
                  ]}
                  onPress={() => setEditedStatus('open')}
                >
                  <Text style={[
                    styles.statusText,
                    editedStatus === 'open' && styles.selectedStatusText
                  ]}>
                    {t('open')}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.statusButton,
                    editedStatus === 'in_progress' && styles.selectedStatusButton
                  ]}
                  onPress={() => setEditedStatus('in_progress')}
                >
                  <Text style={[
                    styles.statusText,
                    editedStatus === 'in_progress' && styles.selectedStatusText
                  ]}>
                    {t('inProgress')}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.statusButton,
                    styles.statusButtonLast,
                    editedStatus === 'closed' && styles.selectedStatusButton
                  ]}
                  onPress={() => setEditedStatus('closed')}
                >
                  <Text style={[
                    styles.statusText,
                    editedStatus === 'closed' && styles.selectedStatusText
                  ]}>
                    {t('closed')}
                  </Text>
                </TouchableOpacity>
              </View>
              
              <Text style={styles.label}>{t('deadline')}</Text>
              <TextInput
                style={styles.input}
                value={editedDeadline}
                onChangeText={setEditedDeadline}
                placeholder="YYYY-MM-DD"
                placeholderTextColor={theme.text + '60'}
              />
              
              <TouchableOpacity 
                style={styles.addButton}
                onPress={saveChanges}
              >
                <Ionicons name="save-outline" size={24} color="white" />
                <Text style={styles.addButtonText}>{t('saveChanges')}</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <Text style={styles.label}>{t('title')}</Text>
              <Text style={styles.value}>{caseData.title}</Text>
              
              <Text style={styles.label}>{t('description')}</Text>
              <Text style={styles.value}>{caseData.description || t('noDescription')}</Text>
              
              <Text style={styles.label}>{t('status')}</Text>
              <View style={[
                styles.statusBadge,
                { backgroundColor: getStatusColor(caseData.status) + '20' }
              ]}>
                <Text style={[
                  styles.statusBadgeText,
                  { color: getStatusColor(caseData.status) }
                ]}>
                  {getStatusText(caseData.status)}
                </Text>
              </View>
              
              <Text style={styles.label}>{t('deadline')}</Text>
              <Text style={styles.value}>
                {caseData.deadline 
                  ? new Date(caseData.deadline).toLocaleDateString() 
                  : t('noDeadline')}
              </Text>
              
              <Text style={styles.label}>{t('created')}</Text>
              <Text style={styles.value}>
                {new Date(caseData.created_at).toLocaleString()}
              </Text>
              
              <Text style={styles.label}>{t('updated')}</Text>
              <Text style={styles.value}>
                {new Date(caseData.updated_at).toLocaleString()}
              </Text>
            </>
          )}
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('documents')}</Text>
          
          {documents.length > 0 ? (
            <FlatList
              data={documents}
              renderItem={renderDocumentItem}
              keyExtractor={(item) => item.id.toString()}
              scrollEnabled={false}
            />
          ) : (
            <Text style={{ color: theme.text + '80', marginBottom: 10 }}>
              {t('noDocuments')}
            </Text>
          )}
          
          <TouchableOpacity 
            style={styles.addButton}
            onPress={attachDocument}
          >
            <Ionicons name="attach-outline" size={24} color="white" />
            <Text style={styles.addButtonText}>{t('attachDocument')}</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('notes')}</Text>
          
          {notes.length > 0 ? (
            <FlatList
              data={notes}
              renderItem={renderNoteItem}
              keyExtractor={(item) => item.id.toString()}
              scrollEnabled={false}
            />
          ) : (
            <Text style={{ color: theme.text + '80', marginBottom: 10 }}>
              {t('noNotes')}
            </Text>
          )}
          
          <View style={styles.addNoteContainer}>
            <TextInput
              style={styles.noteInput}
              value={newNote}
              onChangeText={setNewNote}
              placeholder={t('addNote')}
              placeholderTextColor={theme.text + '60'}
            />
            <TouchableOpacity 
              style={[
                styles.sendButton,
                { opacity: newNote.trim() === '' || addingNote ? 0.7 : 1 }
              ]} 
              onPress={addNote}
              disabled={newNote.trim() === '' || addingNote}
            >
              {addingNote ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <Ionicons name="send" size={20} color="white" />
              )}
            </TouchableOpacity>
          </View>
        </View>
        
        <TouchableOpacity 
          style={styles.deleteButton}
          onPress={deleteCase}
        >
          <Ionicons name="trash-outline" size={24} color="white" />
          <Text style={styles.addButtonText}>{t('deleteCase')}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default CaseDetailScreen;
