import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const LawDetailScreen = ({ route, navigation }) => {
  const { lawId, title } = route.params;
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [law, setLaw] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expandedSections, setExpandedSections] = useState({});

  useEffect(() => {
    navigation.setOptions({
      title: title,
    });
    
    fetchLawDetails();
  }, [lawId]);

  const fetchLawDetails = async () => {
    try {
      setLoading(true);
      
      // In a real app, this would call the backend API to fetch law details
      // For now, we'll simulate a delay and return mock data
      
      setTimeout(() => {
        const mockLaw = {
          id: lawId,
          title: title,
          reference: 'LOV-2018-06-15-38',
          jurisdiction: 'NO',
          category: 'administrative',
          publicationDate: '2018-06-15',
          effectiveDate: '2018-07-20',
          lastAmended: '2021-05-01',
          description: 'Loven gjelder behandling av personopplysninger som helt eller delvis skjer med elektroniske hjelpemidler og annen behandling av personopplysninger når disse inngår eller skal inngå i et register. Loven gjelder ikke behandling av personopplysninger som utføres av en fysisk person som ledd i rent personlige eller private aktiviteter.',
          sections: [
            {
              id: 1,
              title: 'Kapittel 1. Innledende bestemmelser',
              articles: [
                {
                  id: 1,
                  number: '§ 1',
                  title: 'Formål',
                  text: 'Loven skal beskytte fysiske personer i forbindelse med behandling av personopplysninger og sikre at behandling av slike opplysninger utføres i samsvar med grunnleggende personvernprinsipper.',
                },
                {
                  id: 2,
                  number: '§ 2',
                  title: 'Saklig virkeområde',
                  text: 'Loven og personvernforordningen gjelder ved helt eller delvis automatisert behandling av personopplysninger og ved ikke-automatisert behandling av personopplysninger som inngår i eller skal inngå i et register.',
                },
              ],
            },
            {
              id: 2,
              title: 'Kapittel 2. Behandling av personopplysninger',
              articles: [
                {
                  id: 3,
                  number: '§ 3',
                  title: 'Lovlig behandling',
                  text: 'Personopplysninger kan bare behandles dersom det foreligger et behandlingsgrunnlag etter personvernforordningen artikkel 6.',
                },
                {
                  id: 4,
                  number: '§ 4',
                  title: 'Behandling av særlige kategorier av personopplysninger',
                  text: 'Behandling av særlige kategorier av personopplysninger er forbudt med mindre behandlingen oppfyller minst ett av vilkårene i personvernforordningen artikkel 9 nr. 2.',
                },
              ],
            },
          ],
          relatedLaws: [
            {
              id: 5,
              title: 'Lov om behandlingsmåten i forvaltningssaker (forvaltningsloven)',
              reference: 'LOV-1967-02-10',
            },
            {
              id: 6,
              title: 'Lov om rett til innsyn i dokument i offentleg verksemd (offentleglova)',
              reference: 'LOV-2006-05-19-16',
            },
          ],
        };
        
        setLaw(mockLaw);
        setLoading(false);
      }, 1000);
      
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };

  const toggleSection = (sectionId) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    content: {
      padding: 15,
    },
    header: {
      marginBottom: 20,
    },
    title: {
      fontSize: 22,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 10,
    },
    reference: {
      fontSize: 16,
      color: theme.text + '80',
      marginBottom: 5,
    },
    metaContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      marginBottom: 10,
    },
    metaItem: {
      flexDirection: 'row',
      alignItems: 'center',
      marginRight: 15,
      marginBottom: 5,
    },
    metaText: {
      fontSize: 14,
      color: theme.text + '60',
      marginLeft: 5,
    },
    description: {
      fontSize: 16,
      color: theme.text,
      lineHeight: 24,
      backgroundColor: theme.card,
      padding: 15,
      borderRadius: 5,
      marginBottom: 20,
    },
    sectionContainer: {
      marginBottom: 15,
    },
    sectionHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      backgroundColor: theme.primary,
      padding: 15,
      borderRadius: 5,
    },
    sectionTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: 'white',
      flex: 1,
    },
    sectionContent: {
      backgroundColor: theme.card,
      borderBottomLeftRadius: 5,
      borderBottomRightRadius: 5,
      marginTop: 1,
    },
    article: {
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    articleHeader: {
      flexDirection: 'row',
      marginBottom: 5,
    },
    articleNumber: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginRight: 10,
    },
    articleTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
    },
    articleText: {
      fontSize: 15,
      color: theme.text,
      lineHeight: 22,
    },
    relatedLawsContainer: {
      marginTop: 20,
    },
    relatedLawsTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 10,
    },
    relatedLawItem: {
      backgroundColor: theme.card,
      padding: 15,
      borderRadius: 5,
      marginBottom: 10,
      flexDirection: 'row',
      alignItems: 'center',
    },
    relatedLawInfo: {
      flex: 1,
    },
    relatedLawTitle: {
      fontSize: 15,
      color: theme.text,
      marginBottom: 5,
    },
    relatedLawReference: {
      fontSize: 14,
      color: theme.text + '80',
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
    actionButton: {
      backgroundColor: theme.primary,
      padding: 15,
      borderRadius: 5,
      alignItems: 'center',
      marginTop: 20,
      flexDirection: 'row',
      justifyContent: 'center',
    },
    actionButtonText: {
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
      marginLeft: 10,
    },
  });

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (!law) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 20 }]}>
        <Text style={{ color: theme.text, textAlign: 'center' }}>
          {error || t('lawNotFound')}
        </Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>{law.title}</Text>
          <Text style={styles.reference}>{law.reference}</Text>
          
          <View style={styles.metaContainer}>
            <View style={styles.metaItem}>
              <Ionicons name="calendar-outline" size={16} color={theme.text + '60'} />
              <Text style={styles.metaText}>{t('published')}: {law.publicationDate}</Text>
            </View>
            <View style={styles.metaItem}>
              <Ionicons name="play-outline" size={16} color={theme.text + '60'} />
              <Text style={styles.metaText}>{t('effective')}: {law.effectiveDate}</Text>
            </View>
            <View style={styles.metaItem}>
              <Ionicons name="refresh-outline" size={16} color={theme.text + '60'} />
              <Text style={styles.metaText}>{t('amended')}: {law.lastAmended}</Text>
            </View>
          </View>
        </View>
        
        <Text style={styles.description}>{law.description}</Text>
        
        {law.sections.map(section => (
          <View key={section.id} style={styles.sectionContainer}>
            <TouchableOpacity 
              style={styles.sectionHeader}
              onPress={() => toggleSection(section.id)}
            >
              <Text style={styles.sectionTitle}>{section.title}</Text>
              <Ionicons 
                name={expandedSections[section.id] ? "chevron-up" : "chevron-down"} 
                size={24} 
                color="white" 
              />
            </TouchableOpacity>
            
            {expandedSections[section.id] && (
              <View style={styles.sectionContent}>
                {section.articles.map(article => (
                  <View key={article.id} style={styles.article}>
                    <View style={styles.articleHeader}>
                      <Text style={styles.articleNumber}>{article.number}</Text>
                      <Text style={styles.articleTitle}>{article.title}</Text>
                    </View>
                    <Text style={styles.articleText}>{article.text}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        ))}
        
        {law.relatedLaws && law.relatedLaws.length > 0 && (
          <View style={styles.relatedLawsContainer}>
            <Text style={styles.relatedLawsTitle}>{t('relatedLaws')}</Text>
            
            {law.relatedLaws.map(relatedLaw => (
              <TouchableOpacity 
                key={relatedLaw.id}
                style={styles.relatedLawItem}
                onPress={() => navigation.push('LawDetail', { 
                  lawId: relatedLaw.id,
                  title: relatedLaw.title
                })}
              >
                <View style={styles.relatedLawInfo}>
                  <Text style={styles.relatedLawTitle}>{relatedLaw.title}</Text>
                  <Text style={styles.relatedLawReference}>{relatedLaw.reference}</Text>
                </View>
                <Ionicons name="chevron-forward" size={24} color={theme.primary} />
              </TouchableOpacity>
            ))}
          </View>
        )}
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => {
            // In a real app, this would add the law to a case or document
            navigation.navigate('Chat');
          }}
        >
          <Ionicons name="chatbubble-outline" size={24} color="white" />
          <Text style={styles.actionButtonText}>{t('askAboutThisLaw')}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default LawDetailScreen;
