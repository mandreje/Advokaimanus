import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const LawSearchScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [jurisdiction, setJurisdiction] = useState('NO'); // Default to Norway
  const [category, setCategory] = useState('all');
  
  const jurisdictions = [
    { id: 'NO', name: 'Norge', flag: '🇳🇴' },
    { id: 'SE', name: 'Sverige', flag: '🇸🇪' },
    { id: 'DK', name: 'Danmark', flag: '🇩🇰' },
    { id: 'EU', name: 'EU', flag: '🇪🇺' },
  ];
  
  const categories = [
    { id: 'all', name: t('allCategories') },
    { id: 'civil', name: t('civilLaw') },
    { id: 'criminal', name: t('criminalLaw') },
    { id: 'administrative', name: t('administrativeLaw') },
    { id: 'tax', name: t('taxLaw') },
    { id: 'labor', name: t('laborLaw') },
  ];

  const handleSearch = async () => {
    if (searchQuery.trim() === '') {
      return;
    }
    
    try {
      setLoading(true);
      setError('');
      
      // In a real app, this would call the backend API to search for laws
      // For now, we'll simulate a delay and return mock results
      
      setTimeout(() => {
        const mockResults = [
          {
            id: 1,
            title: 'Lov om behandling av personopplysninger (personopplysningsloven)',
            reference: 'LOV-2018-06-15-38',
            excerpt: 'Loven gjelder behandling av personopplysninger som helt eller delvis skjer med elektroniske hjelpemidler...',
            jurisdiction: 'NO',
            category: 'administrative',
            relevance: 95,
          },
          {
            id: 2,
            title: 'Lov om avtaler om forbrukerkjøp (forbrukerkjøpsloven)',
            reference: 'LOV-2002-06-21-34',
            excerpt: 'Loven gjelder forbrukerkjøp hvis ikke annet følger av annen lovgivning...',
            jurisdiction: 'NO',
            category: 'civil',
            relevance: 87,
          },
          {
            id: 3,
            title: 'Lov om arbeidsmiljø, arbeidstid og stillingsvern mv. (arbeidsmiljøloven)',
            reference: 'LOV-2005-06-17-62',
            excerpt: 'Lovens formål er å sikre et arbeidsmiljø som gir grunnlag for en helsefremmende og meningsfylt arbeidssituasjon...',
            jurisdiction: 'NO',
            category: 'labor',
            relevance: 82,
          },
        ];
        
        // Filter by jurisdiction and category
        let filteredResults = mockResults.filter(result => 
          result.jurisdiction === jurisdiction
        );
        
        if (category !== 'all') {
          filteredResults = filteredResults.filter(result => 
            result.category === category
          );
        }
        
        setResults(filteredResults);
        setLoading(false);
      }, 1000);
      
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.resultItem}
      onPress={() => navigation.navigate('LawDetail', { lawId: item.id, title: item.title })}
    >
      <View style={styles.resultHeader}>
        <Text style={styles.resultTitle}>{item.title}</Text>
        <View style={styles.relevanceBadge}>
          <Text style={styles.relevanceText}>{item.relevance}%</Text>
        </View>
      </View>
      <Text style={styles.resultReference}>{item.reference}</Text>
      <Text style={styles.resultExcerpt} numberOfLines={2}>{item.excerpt}</Text>
    </TouchableOpacity>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    searchContainer: {
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    searchInputContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      borderRadius: 5,
      paddingHorizontal: 10,
      marginBottom: 15,
    },
    searchInput: {
      flex: 1,
      padding: 10,
      color: theme.text,
    },
    searchButton: {
      padding: 10,
    },
    filtersContainer: {
      marginBottom: 15,
    },
    filterLabel: {
      fontSize: 14,
      color: theme.text,
      marginBottom: 5,
    },
    jurisdictionContainer: {
      flexDirection: 'row',
      marginBottom: 10,
    },
    jurisdictionButton: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 15,
      paddingVertical: 8,
      borderRadius: 20,
      backgroundColor: theme.card,
      marginRight: 10,
    },
    selectedJurisdictionButton: {
      backgroundColor: theme.primary,
    },
    jurisdictionFlag: {
      marginRight: 5,
      fontSize: 16,
    },
    jurisdictionText: {
      color: theme.text,
      fontSize: 14,
    },
    selectedJurisdictionText: {
      color: 'white',
    },
    categoriesContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
    },
    categoryButton: {
      paddingHorizontal: 15,
      paddingVertical: 8,
      borderRadius: 20,
      backgroundColor: theme.card,
      marginRight: 10,
      marginBottom: 10,
    },
    selectedCategoryButton: {
      backgroundColor: theme.primary,
    },
    categoryText: {
      color: theme.text,
      fontSize: 14,
    },
    selectedCategoryText: {
      color: 'white',
    },
    resultItem: {
      backgroundColor: theme.card,
      padding: 15,
      borderRadius: 5,
      marginBottom: 10,
    },
    resultHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      marginBottom: 5,
    },
    resultTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      flex: 1,
      marginRight: 10,
    },
    relevanceBadge: {
      backgroundColor: theme.primary,
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 10,
    },
    relevanceText: {
      color: 'white',
      fontSize: 12,
      fontWeight: 'bold',
    },
    resultReference: {
      fontSize: 14,
      color: theme.text + '80',
      marginBottom: 5,
    },
    resultExcerpt: {
      fontSize: 14,
      color: theme.text,
    },
    resultsContainer: {
      flex: 1,
      padding: 15,
    },
    noResultsContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 20,
    },
    noResultsText: {
      fontSize: 16,
      color: theme.text + '80',
      textAlign: 'center',
      marginTop: 10,
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder={t('searchLaws')}
            placeholderTextColor={theme.text + '60'}
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
            onSubmitEditing={handleSearch}
          />
          <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
            <Ionicons name="search" size={24} color={theme.primary} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.filtersContainer}>
          <Text style={styles.filterLabel}>{t('jurisdiction')}:</Text>
          <View style={styles.jurisdictionContainer}>
            {jurisdictions.map(item => (
              <TouchableOpacity
                key={item.id}
                style={[
                  styles.jurisdictionButton,
                  jurisdiction === item.id && styles.selectedJurisdictionButton
                ]}
                onPress={() => setJurisdiction(item.id)}
              >
                <Text style={styles.jurisdictionFlag}>{item.flag}</Text>
                <Text style={[
                  styles.jurisdictionText,
                  jurisdiction === item.id && styles.selectedJurisdictionText
                ]}>
                  {item.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          
          <Text style={styles.filterLabel}>{t('category')}:</Text>
          <View style={styles.categoriesContainer}>
            {categories.map(item => (
              <TouchableOpacity
                key={item.id}
                style={[
                  styles.categoryButton,
                  category === item.id && styles.selectedCategoryButton
                ]}
                onPress={() => setCategory(item.id)}
              >
                <Text style={[
                  styles.categoryText,
                  category === item.id && styles.selectedCategoryText
                ]}>
                  {item.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>
      
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      
      {loading ? (
        <View style={[styles.resultsContainer, { justifyContent: 'center', alignItems: 'center' }]}>
          <ActivityIndicator size="large" color={theme.primary} />
        </View>
      ) : results.length > 0 ? (
        <FlatList
          data={results}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.resultsContainer}
        />
      ) : searchQuery.trim() !== '' ? (
        <View style={styles.noResultsContainer}>
          <Ionicons name="search-outline" size={60} color={theme.text + '40'} />
          <Text style={styles.noResultsText}>{t('noResultsFound')}</Text>
        </View>
      ) : (
        <View style={styles.noResultsContainer}>
          <Ionicons name="book-outline" size={60} color={theme.text + '40'} />
          <Text style={styles.noResultsText}>{t('searchLawsInstructions')}</Text>
        </View>
      )}
    </View>
  );
};

export default LawSearchScreen;
