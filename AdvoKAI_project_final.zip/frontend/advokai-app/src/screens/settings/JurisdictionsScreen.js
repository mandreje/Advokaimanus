import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const JurisdictionsScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('NO');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    fetchUserJurisdiction();
  }, []);
  
  const fetchUserJurisdiction = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data, error } = await supabase
          .from('profiles')
          .select('preferred_jurisdiction')
          .eq('id', user.id)
          .single();
          
        if (error && error.code !== 'PGRST116') {
          throw error;
        }
        
        if (data && data.preferred_jurisdiction) {
          setSelectedJurisdiction(data.preferred_jurisdiction);
        }
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
  
  const saveJurisdiction = async (jurisdiction) => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          preferred_jurisdiction: jurisdiction,
          updated_at: new Date().toISOString(),
        });
        
      if (error) throw error;
      
      setSelectedJurisdiction(jurisdiction);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
  
  const jurisdictions = [
    {
      code: 'NO',
      name: 'Norge',
      flag: '🇳🇴',
      description: t('norwayJurisdictionDesc'),
      sources: [
        { name: 'Lovdata', description: t('lovdataDesc') },
        { name: 'Brønnøysundregistrene', description: t('brregDesc') },
        { name: 'NAV', description: t('navDesc') },
      ],
    },
    {
      code: 'SE',
      name: 'Sverige',
      flag: '🇸🇪',
      description: t('swedenJurisdictionDesc'),
      sources: [
        { name: 'Riksdagen API', description: t('riksdagenDesc') },
        { name: 'Skatteverket', description: t('skatteverketDesc') },
      ],
    },
    {
      code: 'DK',
      name: 'Danmark',
      flag: '🇩🇰',
      description: t('denmarkJurisdictionDesc'),
      sources: [
        { name: 'Retsinformation.dk', description: t('retsinformationDesc') },
      ],
    },
    {
      code: 'EU',
      name: 'EU/International',
      flag: '🇪🇺',
      description: t('euJurisdictionDesc'),
      sources: [
        { name: 'EUR-Lex', description: t('eurLexDesc') },
        { name: 'EU Treaties', description: t('euTreatiesDesc') },
      ],
    },
  ];
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    content: {
      padding: 15,
    },
    header: {
      marginBottom: 20,
    },
    title: {
      fontSize: 22,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 10,
    },
    description: {
      fontSize: 16,
      color: theme.text + '80',
      lineHeight: 22,
    },
    jurisdictionCard: {
      backgroundColor: theme.card,
      borderRadius: 10,
      marginBottom: 15,
      borderWidth: 2,
      borderColor: 'transparent',
      overflow: 'hidden',
    },
    selectedCard: {
      borderColor: theme.primary,
    },
    jurisdictionHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    jurisdictionFlag: {
      fontSize: 24,
      marginRight: 10,
    },
    jurisdictionName: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      flex: 1,
    },
    selectedBadge: {
      backgroundColor: theme.primary,
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 15,
    },
    selectedBadgeText: {
      color: 'white',
      fontSize: 12,
      fontWeight: 'bold',
    },
    jurisdictionBody: {
      padding: 15,
    },
    jurisdictionDescription: {
      fontSize: 14,
      color: theme.text,
      lineHeight: 20,
      marginBottom: 15,
    },
    sourcesTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 10,
    },
    sourceItem: {
      marginBottom: 10,
    },
    sourceName: {
      fontSize: 14,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 3,
    },
    sourceDescription: {
      fontSize: 13,
      color: theme.text + '80',
      lineHeight: 18,
    },
    selectButton: {
      backgroundColor: theme.primary,
      borderRadius: 5,
      padding: 12,
      alignItems: 'center',
      marginTop: 10,
    },
    selectButtonText: {
      color: 'white',
      fontSize: 16,
      fontWeight: 'bold',
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });
  
  if (loading && selectedJurisdiction === null) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        
        <View style={styles.header}>
          <Text style={styles.title}>{t('selectJurisdiction')}</Text>
          <Text style={styles.description}>
            {t('jurisdictionDescription')}
          </Text>
        </View>
        
        {jurisdictions.map(jurisdiction => (
          <View 
            key={jurisdiction.code} 
            style={[
              styles.jurisdictionCard,
              selectedJurisdiction === jurisdiction.code && styles.selectedCard
            ]}
          >
            <View style={styles.jurisdictionHeader}>
              <Text style={styles.jurisdictionFlag}>{jurisdiction.flag}</Text>
              <Text style={styles.jurisdictionName}>{jurisdiction.name}</Text>
              
              {selectedJurisdiction === jurisdiction.code && (
                <View style={styles.selectedBadge}>
                  <Text style={styles.selectedBadgeText}>{t('selected')}</Text>
                </View>
              )}
            </View>
            
            <View style={styles.jurisdictionBody}>
              <Text style={styles.jurisdictionDescription}>
                {jurisdiction.description}
              </Text>
              
              <Text style={styles.sourcesTitle}>{t('legalSources')}:</Text>
              
              {jurisdiction.sources.map((source, index) => (
                <View key={index} style={styles.sourceItem}>
                  <Text style={styles.sourceName}>{source.name}</Text>
                  <Text style={styles.sourceDescription}>{source.description}</Text>
                </View>
              ))}
              
              {selectedJurisdiction !== jurisdiction.code && (
                <TouchableOpacity 
                  style={styles.selectButton}
                  onPress={() => saveJurisdiction(jurisdiction.code)}
                  disabled={loading}
                >
                  {loading ? (
                    <ActivityIndicator size="small" color="white" />
                  ) : (
                    <Text style={styles.selectButtonText}>{t('select')}</Text>
                  )}
                </TouchableOpacity>
              )}
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

export default JurisdictionsScreen;
