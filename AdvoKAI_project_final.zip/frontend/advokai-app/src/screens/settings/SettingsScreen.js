import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme, useThemeUpdate } from '../../utils/ThemeContext';
import { useLanguage, useLanguageUpdate, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const SettingsScreen = ({ navigation }) => {
  const { theme, isDark } = useTheme();
  const toggleTheme = useThemeUpdate();
  const { language } = useLanguage();
  const setLanguage = useLanguageUpdate();
  const t = (key) => getTranslation(key, language);
  
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    fetchUserProfile();
  }, []);
  
  const fetchUserProfile = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        setUser(user);
        
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
          
        if (error && error.code !== 'PGRST116') {
          throw error;
        }
        
        setProfile(data || { id: user.id });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleSignOut = async () => {
    Alert.alert(
      t('signOut'),
      t('signOutConfirmation'),
      [
        {
          text: t('cancel'),
          style: 'cancel',
        },
        {
          text: t('signOut'),
          onPress: async () => {
            await supabase.auth.signOut();
            navigation.reset({
              index: 0,
              routes: [{ name: 'Login' }],
            });
          },
        },
      ],
    );
  };
  
  const languages = [
    { code: 'no', name: 'Norsk', flag: '🇳🇴' },
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'sv', name: 'Svenska', flag: '🇸🇪' },
    { code: 'da', name: 'Dansk', flag: '🇩🇰' },
  ];
  
  const jurisdictions = [
    { code: 'NO', name: 'Norge', flag: '🇳🇴' },
    { code: 'SE', name: 'Sverige', flag: '🇸🇪' },
    { code: 'DK', name: 'Danmark', flag: '🇩🇰' },
    { code: 'EU', name: 'EU/International', flag: '🇪🇺' },
  ];
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    section: {
      backgroundColor: theme.card,
      borderRadius: 10,
      marginHorizontal: 15,
      marginTop: 15,
      padding: 15,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 15,
    },
    row: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    lastRow: {
      borderBottomWidth: 0,
    },
    rowLeft: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    rowIcon: {
      marginRight: 12,
      width: 24,
      alignItems: 'center',
    },
    rowText: {
      fontSize: 16,
      color: theme.text,
    },
    rowValue: {
      fontSize: 16,
      color: theme.text + '80',
    },
    languageRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 10,
    },
    languageFlag: {
      fontSize: 20,
      marginRight: 10,
    },
    languageName: {
      fontSize: 16,
      color: theme.text,
    },
    selectedLanguage: {
      color: theme.primary,
      fontWeight: 'bold',
    },
    signOutButton: {
      backgroundColor: theme.error,
      borderRadius: 10,
      marginHorizontal: 15,
      marginTop: 30,
      marginBottom: 20,
      padding: 15,
      alignItems: 'center',
    },
    signOutText: {
      color: 'white',
      fontSize: 16,
      fontWeight: 'bold',
    },
    versionText: {
      textAlign: 'center',
      color: theme.text + '60',
      fontSize: 14,
      marginTop: 20,
      marginBottom: 30,
    },
  });
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('account')}</Text>
        
        <TouchableOpacity 
          style={styles.row}
          onPress={() => navigation.navigate('Profile')}
        >
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Ionicons name="person-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.rowText}>{t('profile')}</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={theme.text + '60'} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.row}
          onPress={() => navigation.navigate('Tokens')}
        >
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Ionicons name="wallet-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.rowText}>{t('tokens')}</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={theme.text + '60'} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.row, styles.lastRow]}
          onPress={() => navigation.navigate('Subscription')}
        >
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Ionicons name="card-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.rowText}>{t('subscription')}</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={theme.text + '60'} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('appearance')}</Text>
        
        <View style={[styles.row, styles.lastRow]}>
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Ionicons name="moon-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.rowText}>{t('darkMode')}</Text>
          </View>
          <Switch
            value={isDark}
            onValueChange={toggleTheme}
            trackColor={{ false: theme.border, true: theme.primary + '80' }}
            thumbColor={isDark ? theme.primary : theme.text + '40'}
          />
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('language')}</Text>
        
        {languages.map((lang, index) => (
          <TouchableOpacity 
            key={lang.code}
            style={[
              styles.row, 
              index === languages.length - 1 && styles.lastRow,
              { justifyContent: 'flex-start' }
            ]}
            onPress={() => setLanguage(lang.code)}
          >
            <Text style={styles.languageFlag}>{lang.flag}</Text>
            <Text style={[
              styles.languageName,
              language === lang.code && styles.selectedLanguage
            ]}>
              {lang.name}
            </Text>
            {language === lang.code && (
              <Ionicons 
                name="checkmark" 
                size={20} 
                color={theme.primary}
                style={{ marginLeft: 10 }}
              />
            )}
          </TouchableOpacity>
        ))}
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('jurisdiction')}</Text>
        
        {jurisdictions.map((jurisdiction, index) => (
          <TouchableOpacity 
            key={jurisdiction.code}
            style={[
              styles.row, 
              index === jurisdictions.length - 1 && styles.lastRow,
              { justifyContent: 'flex-start' }
            ]}
            onPress={() => navigation.navigate('Jurisdictions')}
          >
            <Text style={styles.languageFlag}>{jurisdiction.flag}</Text>
            <Text style={styles.languageName}>
              {jurisdiction.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t('about')}</Text>
        
        <TouchableOpacity 
          style={styles.row}
          onPress={() => navigation.navigate('PrivacyPolicy')}
        >
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Ionicons name="shield-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.rowText}>{t('privacyPolicy')}</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={theme.text + '60'} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.row}
          onPress={() => navigation.navigate('TermsOfService')}
        >
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Ionicons name="document-text-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.rowText}>{t('termsOfService')}</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={theme.text + '60'} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.row, styles.lastRow]}
          onPress={() => navigation.navigate('Help')}
        >
          <View style={styles.rowLeft}>
            <View style={styles.rowIcon}>
              <Ionicons name="help-circle-outline" size={24} color={theme.primary} />
            </View>
            <Text style={styles.rowText}>{t('help')}</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={theme.text + '60'} />
        </TouchableOpacity>
      </View>
      
      <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
        <Text style={styles.signOutText}>{t('signOut')}</Text>
      </TouchableOpacity>
      
      <Text style={styles.versionText}>AdvoKAI v1.0.0</Text>
    </ScrollView>
  );
};

export default SettingsScreen;
