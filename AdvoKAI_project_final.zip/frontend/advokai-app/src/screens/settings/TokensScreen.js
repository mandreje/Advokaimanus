import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const TokensScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [user, setUser] = useState(null);
  const [tokens, setTokens] = useState(0);
  const [tokenHistory, setTokenHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    fetchUserTokens();
    fetchTokenHistory();
  }, []);
  
  const fetchUserTokens = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        setUser(user);
        
        const { data, error } = await supabase
          .from('profiles')
          .select('tokens')
          .eq('id', user.id)
          .single();
          
        if (error && error.code !== 'PGRST116') {
          throw error;
        }
        
        setTokens(data?.tokens || 0);
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
  
  const fetchTokenHistory = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('token_transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      
      setTokenHistory(data || []);
    } catch (error) {
      setError(error.message);
    }
  };
  
  const getTokenPackages = () => [
    { id: 1, name: t('basicPackage'), amount: 100, price: 99, popular: false },
    { id: 2, name: t('standardPackage'), amount: 500, price: 399, popular: true },
    { id: 3, name: t('premiumPackage'), amount: 1000, price: 699, popular: false },
  ];
  
  const getSubscriptionPlans = () => [
    { id: 1, name: t('basicPlan'), tokens: 200, price: 149, popular: false },
    { id: 2, name: t('proPlan'), tokens: 1000, price: 499, popular: true },
    { id: 3, name: t('enterprisePlan'), tokens: 5000, price: 1999, popular: false },
  ];
  
  const purchaseTokens = async (packageId) => {
    // In a real app, this would navigate to a payment screen
    // For now, we'll simulate adding tokens
    
    try {
      const tokenPackage = getTokenPackages().find(pkg => pkg.id === packageId);
      
      if (!tokenPackage) throw new Error('Invalid package');
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      // Update user tokens
      const { data, error } = await supabase
        .from('profiles')
        .update({ 
          tokens: tokens + tokenPackage.amount,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id)
        .select();

      if (error) throw error;
      
      // Record transaction
      await supabase
        .from('token_transactions')
        .insert([
          { 
            user_id: user.id,
            amount: tokenPackage.amount,
            transaction_type: 'purchase',
            description: `Purchased ${tokenPackage.name}`,
          }
        ]);
        
      setTokens(data[0].tokens);
      fetchTokenHistory();
    } catch (error) {
      setError(error.message);
    }
  };
  
  const subscribeToTokenPlan = async (planId) => {
    // In a real app, this would navigate to a subscription screen
    // For now, we'll simulate subscribing
    
    try {
      const plan = getSubscriptionPlans().find(p => p.id === planId);
      
      if (!plan) throw new Error('Invalid plan');
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      // Update user subscription
      const { error } = await supabase
        .from('profiles')
        .update({ 
          subscription_plan: planId,
          subscription_start: new Date().toISOString(),
          subscription_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) throw error;
      
      // Add initial tokens
      await supabase
        .from('profiles')
        .update({ 
          tokens: tokens + plan.tokens,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);
        
      // Record transaction
      await supabase
        .from('token_transactions')
        .insert([
          { 
            user_id: user.id,
            amount: plan.tokens,
            transaction_type: 'subscription',
            description: `Subscribed to ${plan.name}`,
          }
        ]);
        
      fetchUserTokens();
      fetchTokenHistory();
    } catch (error) {
      setError(error.message);
    }
  };
  
  const getTransactionIcon = (type) => {
    switch (type) {
      case 'purchase':
        return 'cart-outline';
      case 'subscription':
        return 'calendar-outline';
      case 'usage':
        return 'remove-circle-outline';
      case 'bonus':
        return 'gift-outline';
      default:
        return 'swap-horizontal-outline';
    }
  };
  
  const getTransactionColor = (type) => {
    switch (type) {
      case 'purchase':
      case 'subscription':
      case 'bonus':
        return theme.success;
      case 'usage':
        return theme.warning;
      default:
        return theme.primary;
    }
  };
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    content: {
      padding: 15,
    },
    tokenCard: {
      backgroundColor: theme.primary,
      borderRadius: 10,
      padding: 20,
      marginBottom: 20,
    },
    tokenTitle: {
      fontSize: 16,
      color: 'white',
      opacity: 0.8,
      marginBottom: 5,
    },
    tokenAmount: {
      fontSize: 36,
      fontWeight: 'bold',
      color: 'white',
    },
    section: {
      backgroundColor: theme.card,
      borderRadius: 10,
      padding: 15,
      marginBottom: 20,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 15,
    },
    packageContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
    },
    packageCard: {
      width: '48%',
      backgroundColor: theme.background,
      borderRadius: 10,
      padding: 15,
      marginBottom: 15,
      borderWidth: 1,
      borderColor: theme.border,
    },
    popularPackage: {
      borderColor: theme.primary,
      borderWidth: 2,
    },
    popularBadge: {
      position: 'absolute',
      top: -10,
      right: 10,
      backgroundColor: theme.primary,
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 15,
    },
    popularBadgeText: {
      color: 'white',
      fontSize: 12,
      fontWeight: 'bold',
    },
    packageName: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 5,
    },
    packageTokens: {
      fontSize: 14,
      color: theme.text + '80',
      marginBottom: 10,
    },
    packagePrice: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.primary,
      marginBottom: 10,
    },
    buyButton: {
      backgroundColor: theme.primary,
      borderRadius: 5,
      padding: 10,
      alignItems: 'center',
    },
    buyButtonText: {
      color: 'white',
      fontWeight: 'bold',
    },
    subscriptionCard: {
      backgroundColor: theme.background,
      borderRadius: 10,
      padding: 15,
      marginBottom: 15,
      borderWidth: 1,
      borderColor: theme.border,
    },
    historyItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    historyIcon: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: theme.background,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 10,
    },
    historyInfo: {
      flex: 1,
    },
    historyDescription: {
      fontSize: 14,
      color: theme.text,
      marginBottom: 3,
    },
    historyDate: {
      fontSize: 12,
      color: theme.text + '60',
    },
    historyAmount: {
      fontSize: 16,
      fontWeight: 'bold',
    },
    positiveAmount: {
      color: theme.success,
    },
    negativeAmount: {
      color: theme.warning,
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });
  
  if (loading && !user) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        
        <View style={styles.tokenCard}>
          <Text style={styles.tokenTitle}>{t('availableTokens')}</Text>
          <Text style={styles.tokenAmount}>{tokens}</Text>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('buyTokens')}</Text>
          
          <View style={styles.packageContainer}>
            {getTokenPackages().map(pkg => (
              <View 
                key={pkg.id} 
                style={[
                  styles.packageCard,
                  pkg.popular && styles.popularPackage
                ]}
              >
                {pkg.popular && (
                  <View style={styles.popularBadge}>
                    <Text style={styles.popularBadgeText}>{t('popular')}</Text>
                  </View>
                )}
                
                <Text style={styles.packageName}>{pkg.name}</Text>
                <Text style={styles.packageTokens}>{pkg.amount} {t('tokens')}</Text>
                <Text style={styles.packagePrice}>{pkg.price} kr</Text>
                
                <TouchableOpacity 
                  style={styles.buyButton}
                  onPress={() => purchaseTokens(pkg.id)}
                >
                  <Text style={styles.buyButtonText}>{t('buy')}</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('subscriptions')}</Text>
          
          {getSubscriptionPlans().map(plan => (
            <View 
              key={plan.id} 
              style={[
                styles.subscriptionCard,
                plan.popular && styles.popularPackage
              ]}
            >
              {plan.popular && (
                <View style={styles.popularBadge}>
                  <Text style={styles.popularBadgeText}>{t('popular')}</Text>
                </View>
              )}
              
              <Text style={styles.packageName}>{plan.name}</Text>
              <Text style={styles.packageTokens}>
                {plan.tokens} {t('tokensMonthly')}
              </Text>
              <Text style={styles.packagePrice}>{plan.price} kr / {t('month')}</Text>
              
              <TouchableOpacity 
                style={styles.buyButton}
                onPress={() => subscribeToTokenPlan(plan.id)}
              >
                <Text style={styles.buyButtonText}>{t('subscribe')}</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('tokenHistory')}</Text>
          
          {tokenHistory.length > 0 ? (
            tokenHistory.map(transaction => (
              <View key={transaction.id} style={styles.historyItem}>
                <View style={[
                  styles.historyIcon,
                  { backgroundColor: getTransactionColor(transaction.transaction_type) + '20' }
                ]}>
                  <Ionicons 
                    name={getTransactionIcon(transaction.transaction_type)} 
                    size={20} 
                    color={getTransactionColor(transaction.transaction_type)} 
                  />
                </View>
                <View style={styles.historyInfo}>
                  <Text style={styles.historyDescription}>
                    {transaction.description}
                  </Text>
                  <Text style={styles.historyDate}>
                    {new Date(transaction.created_at).toLocaleString()}
                  </Text>
                </View>
                <Text style={[
                  styles.historyAmount,
                  transaction.transaction_type === 'usage' 
                    ? styles.negativeAmount 
                    : styles.positiveAmount
                ]}>
                  {transaction.transaction_type === 'usage' ? '-' : '+'}{transaction.amount}
                </Text>
              </View>
            ))
          ) : (
            <Text style={{ color: theme.text + '80' }}>
              {t('noTokenHistory')}
            </Text>
          )}
        </View>
      </View>
    </ScrollView>
  );
};

export default TokensScreen;
