import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const ProfileScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState({
    first_name: '',
    last_name: '',
    phone: '',
    company: '',
    position: '',
    preferred_jurisdiction: 'NO',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  
  useEffect(() => {
    fetchUserProfile();
  }, []);
  
  const fetchUserProfile = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        setUser(user);
        
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
          
        if (error && error.code !== 'PGRST116') {
          throw error;
        }
        
        if (data) {
          setProfile({
            first_name: data.first_name || '',
            last_name: data.last_name || '',
            phone: data.phone || '',
            company: data.company || '',
            position: data.position || '',
            preferred_jurisdiction: data.preferred_jurisdiction || 'NO',
          });
        }
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };
  
  const saveProfile = async () => {
    try {
      setSaving(true);
      setError('');
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          first_name: profile.first_name,
          last_name: profile.last_name,
          phone: profile.phone,
          company: profile.company,
          position: profile.position,
          preferred_jurisdiction: profile.preferred_jurisdiction,
          updated_at: new Date().toISOString(),
        });
        
      if (error) throw error;
      
      navigation.goBack();
    } catch (error) {
      setError(error.message);
    } finally {
      setSaving(false);
    }
  };
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    content: {
      padding: 15,
    },
    section: {
      backgroundColor: theme.card,
      borderRadius: 10,
      padding: 15,
      marginBottom: 20,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 15,
    },
    inputContainer: {
      marginBottom: 15,
    },
    label: {
      fontSize: 14,
      color: theme.text + '80',
      marginBottom: 5,
    },
    input: {
      backgroundColor: theme.background,
      borderRadius: 5,
      borderWidth: 1,
      borderColor: theme.border,
      padding: 12,
      fontSize: 16,
      color: theme.text,
    },
    jurisdictionContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      marginTop: 10,
    },
    jurisdictionButton: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 15,
      paddingVertical: 10,
      borderRadius: 20,
      backgroundColor: theme.background,
      borderWidth: 1,
      borderColor: theme.border,
      marginRight: 10,
      marginBottom: 10,
    },
    selectedJurisdictionButton: {
      backgroundColor: theme.primary + '20',
      borderColor: theme.primary,
    },
    jurisdictionFlag: {
      marginRight: 5,
      fontSize: 16,
    },
    jurisdictionText: {
      color: theme.text,
      fontSize: 14,
    },
    selectedJurisdictionText: {
      color: theme.primary,
      fontWeight: 'bold',
    },
    saveButton: {
      backgroundColor: theme.primary,
      borderRadius: 10,
      padding: 15,
      alignItems: 'center',
      marginTop: 20,
    },
    saveButtonText: {
      color: 'white',
      fontSize: 16,
      fontWeight: 'bold',
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      marginTop: 10,
    },
  });
  
  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('accountInfo')}</Text>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>{t('email')}</Text>
            <TextInput
              style={styles.input}
              value={user?.email}
              editable={false}
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('personalInfo')}</Text>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>{t('firstName')}</Text>
            <TextInput
              style={styles.input}
              value={profile.first_name}
              onChangeText={(text) => setProfile({ ...profile, first_name: text })}
              placeholder={t('enterFirstName')}
              placeholderTextColor={theme.text + '60'}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>{t('lastName')}</Text>
            <TextInput
              style={styles.input}
              value={profile.last_name}
              onChangeText={(text) => setProfile({ ...profile, last_name: text })}
              placeholder={t('enterLastName')}
              placeholderTextColor={theme.text + '60'}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>{t('phone')}</Text>
            <TextInput
              style={styles.input}
              value={profile.phone}
              onChangeText={(text) => setProfile({ ...profile, phone: text })}
              placeholder={t('enterPhone')}
              placeholderTextColor={theme.text + '60'}
              keyboardType="phone-pad"
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('professionalInfo')}</Text>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>{t('company')}</Text>
            <TextInput
              style={styles.input}
              value={profile.company}
              onChangeText={(text) => setProfile({ ...profile, company: text })}
              placeholder={t('enterCompany')}
              placeholderTextColor={theme.text + '60'}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>{t('position')}</Text>
            <TextInput
              style={styles.input}
              value={profile.position}
              onChangeText={(text) => setProfile({ ...profile, position: text })}
              placeholder={t('enterPosition')}
              placeholderTextColor={theme.text + '60'}
            />
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t('preferredJurisdiction')}</Text>
          
          <View style={styles.jurisdictionContainer}>
            <TouchableOpacity
              style={[
                styles.jurisdictionButton,
                profile.preferred_jurisdiction === 'NO' && styles.selectedJurisdictionButton
              ]}
              onPress={() => setProfile({ ...profile, preferred_jurisdiction: 'NO' })}
            >
              <Text style={styles.jurisdictionFlag}>🇳🇴</Text>
              <Text style={[
                styles.jurisdictionText,
                profile.preferred_jurisdiction === 'NO' && styles.selectedJurisdictionText
              ]}>
                Norge
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.jurisdictionButton,
                profile.preferred_jurisdiction === 'SE' && styles.selectedJurisdictionButton
              ]}
              onPress={() => setProfile({ ...profile, preferred_jurisdiction: 'SE' })}
            >
              <Text style={styles.jurisdictionFlag}>🇸🇪</Text>
              <Text style={[
                styles.jurisdictionText,
                profile.preferred_jurisdiction === 'SE' && styles.selectedJurisdictionText
              ]}>
                Sverige
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.jurisdictionButton,
                profile.preferred_jurisdiction === 'DK' && styles.selectedJurisdictionButton
              ]}
              onPress={() => setProfile({ ...profile, preferred_jurisdiction: 'DK' })}
            >
              <Text style={styles.jurisdictionFlag}>🇩🇰</Text>
              <Text style={[
                styles.jurisdictionText,
                profile.preferred_jurisdiction === 'DK' && styles.selectedJurisdictionText
              ]}>
                Danmark
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.jurisdictionButton,
                profile.preferred_jurisdiction === 'EU' && styles.selectedJurisdictionButton
              ]}
              onPress={() => setProfile({ ...profile, preferred_jurisdiction: 'EU' })}
            >
              <Text style={styles.jurisdictionFlag}>🇪🇺</Text>
              <Text style={[
                styles.jurisdictionText,
                profile.preferred_jurisdiction === 'EU' && styles.selectedJurisdictionText
              ]}>
                EU/International
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        
        <TouchableOpacity 
          style={styles.saveButton}
          onPress={saveProfile}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator size="small" color="white" />
          ) : (
            <Text style={styles.saveButtonText}>{t('saveProfile')}</Text>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default ProfileScreen;
