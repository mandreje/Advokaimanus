import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const DocumentGeneratorScreen = ({ route, navigation }) => {
  const { mode = 'description' } = route.params || {};
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [templates, setTemplates] = useState([
    { id: 1, title: 'Arbeidskontrakt', category: 'Arbeid' },
    { id: 2, title: 'Leiekontrakt', category: 'Eiendom' },
    { id: 3, title: 'Kjøpekontrakt', category: 'Eiendom' },
    { id: 4, title: 'Testamente', category: 'Arv' },
    { id: 5, title: 'Fullmakt', category: 'Generelt' },
    { id: 6, title: 'Konfidensialitetsavtale', category: 'Forretning' },
  ]);

  const generateDocument = async () => {
    if (mode === 'template' && !selectedTemplate) {
      setError(t('selectTemplate'));
      return;
    }
    
    if (mode === 'description' && description.trim() === '') {
      setError(t('enterDescription'));
      return;
    }
    
    try {
      setLoading(true);
      setError('');
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      // In a real app, this would call an API to generate the document
      // For now, we'll simulate a delay and create a placeholder document
      
      setTimeout(async () => {
        try {
          const documentTitle = mode === 'template' 
            ? templates.find(t => t.id === selectedTemplate)?.title || 'New Document'
            : 'Document from description';
            
          const { data, error } = await supabase
            .from('documents')
            .insert([
              { 
                user_id: user.id,
                title: documentTitle,
                content: mode === 'description' ? `Generated from description: ${description}` : `Generated from template: ${documentTitle}`,
                document_type: mode === 'template' ? templates.find(t => t.id === selectedTemplate)?.category || 'Other' : 'Custom',
                security_score: Math.floor(Math.random() * 30) + 70, // Random score between 70-99
                is_signed: false,
                metadata: {
                  generation_mode: mode,
                  template_id: selectedTemplate,
                  description: description
                }
              }
            ])
            .select();

          if (error) throw error;
          
          if (data && data.length > 0) {
            navigation.navigate('DocumentView', { 
              documentId: data[0].id,
              title: data[0].title
            });
          }
        } catch (error) {
          setError(error.message);
          setLoading(false);
        }
      }, 2000);
      
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };

  const renderTemplateItem = (template) => (
    <TouchableOpacity
      key={template.id}
      style={[
        styles.templateItem,
        selectedTemplate === template.id && styles.selectedTemplateItem
      ]}
      onPress={() => setSelectedTemplate(template.id)}
    >
      <Ionicons 
        name="document-text-outline" 
        size={24} 
        color={selectedTemplate === template.id ? 'white' : theme.primary} 
      />
      <View style={styles.templateInfo}>
        <Text style={[
          styles.templateTitle,
          selectedTemplate === template.id && styles.selectedTemplateText
        ]}>
          {template.title}
        </Text>
        <Text style={[
          styles.templateCategory,
          selectedTemplate === template.id && styles.selectedTemplateText
        ]}>
          {template.category}
        </Text>
      </View>
      {selectedTemplate === template.id && (
        <Ionicons name="checkmark-circle" size={24} color="white" />
      )}
    </TouchableOpacity>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
      padding: 20,
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 20,
    },
    description: {
      fontSize: 16,
      color: theme.text + '80',
      marginBottom: 30,
    },
    input: {
      backgroundColor: theme.card,
      borderRadius: 5,
      padding: 15,
      color: theme.text,
      height: 150,
      textAlignVertical: 'top',
      marginBottom: 20,
    },
    button: {
      backgroundColor: theme.primary,
      padding: 15,
      borderRadius: 5,
      alignItems: 'center',
      marginTop: 20,
    },
    buttonText: {
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
    },
    errorText: {
      color: theme.error,
      marginBottom: 10,
      textAlign: 'center',
    },
    templateItem: {
      flexDirection: 'row',
      padding: 15,
      borderRadius: 5,
      backgroundColor: theme.card,
      marginBottom: 10,
      alignItems: 'center',
    },
    selectedTemplateItem: {
      backgroundColor: theme.primary,
    },
    templateInfo: {
      flex: 1,
      marginLeft: 15,
    },
    templateTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 5,
    },
    templateCategory: {
      fontSize: 14,
      color: theme.text + '80',
    },
    selectedTemplateText: {
      color: 'white',
    },
    categoriesContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      marginBottom: 20,
    },
    categoryChip: {
      paddingHorizontal: 15,
      paddingVertical: 8,
      borderRadius: 20,
      backgroundColor: theme.card,
      marginRight: 10,
      marginBottom: 10,
    },
    selectedCategoryChip: {
      backgroundColor: theme.primary,
    },
    categoryText: {
      color: theme.text,
    },
    selectedCategoryText: {
      color: 'white',
    },
  });

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>
        {mode === 'template' ? t('selectTemplate') : t('createFromDescription')}
      </Text>
      
      <Text style={styles.description}>
        {mode === 'template' 
          ? t('selectTemplateDescription') 
          : t('createFromDescriptionInstructions')}
      </Text>
      
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      
      {mode === 'template' ? (
        <>
          {templates.map(renderTemplateItem)}
        </>
      ) : (
        <TextInput
          style={styles.input}
          placeholder={t('enterDocumentDescription')}
          placeholderTextColor={theme.text + '60'}
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={6}
        />
      )}
      
      <TouchableOpacity
        style={styles.button}
        onPress={generateDocument}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator size="small" color="white" />
        ) : (
          <Text style={styles.buttonText}>
            {t('generateDocument')}
          </Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
};

export default DocumentGeneratorScreen;
