import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const DocumentListScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDocuments();
  }, []);

  const fetchDocuments = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      
      setDocuments(data || []);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.documentItem}
      onPress={() => navigation.navigate('DocumentView', { 
        documentId: item.id,
        title: item.title
      })}
    >
      <View style={styles.documentIcon}>
        <Ionicons name="document-text-outline" size={24} color={theme.primary} />
      </View>
      <View style={styles.documentInfo}>
        <Text style={styles.documentTitle}>{item.title}</Text>
        <Text style={styles.documentType}>{item.document_type}</Text>
        <View style={styles.documentMeta}>
          <View style={styles.securityScore}>
            <Text style={[
              styles.securityScoreText,
              { color: getScoreColor(item.security_score) }
            ]}>
              {t('securityScore')}: {item.security_score}%
            </Text>
          </View>
          {item.is_signed && (
            <View style={styles.signedBadge}>
              <Ionicons name="checkmark-circle" size={16} color={theme.success} />
              <Text style={styles.signedText}>{t('signed')}</Text>
            </View>
          )}
        </View>
      </View>
      <Text style={styles.documentDate}>
        {new Date(item.updated_at).toLocaleDateString()}
      </Text>
    </TouchableOpacity>
  );

  const getScoreColor = (score) => {
    if (score >= 80) return theme.success;
    if (score >= 50) return theme.warning;
    return theme.error;
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    documentItem: {
      flexDirection: 'row',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
      alignItems: 'center',
    },
    documentIcon: {
      width: 50,
      height: 50,
      borderRadius: 25,
      backgroundColor: theme.card,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 15,
    },
    documentInfo: {
      flex: 1,
    },
    documentTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 5,
    },
    documentType: {
      fontSize: 14,
      color: theme.text + '80',
      marginBottom: 5,
    },
    documentMeta: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    securityScore: {
      marginRight: 10,
    },
    securityScoreText: {
      fontSize: 12,
    },
    signedBadge: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    signedText: {
      fontSize: 12,
      color: theme.success,
      marginLeft: 3,
    },
    documentDate: {
      fontSize: 12,
      color: theme.text + '60',
    },
    fab: {
      position: 'absolute',
      width: 60,
      height: 60,
      borderRadius: 30,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
      right: 20,
      bottom: 20,
      elevation: 5,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 3,
    },
    fabIcon: {
      color: 'white',
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 20,
    },
    emptyText: {
      fontSize: 16,
      color: theme.text + '80',
      textAlign: 'center',
      marginTop: 10,
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
    actionMenu: {
      position: 'absolute',
      right: 20,
      bottom: 90,
      backgroundColor: theme.card,
      borderRadius: 5,
      elevation: 5,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 3,
    },
    actionMenuItem: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    actionMenuItemText: {
      color: theme.text,
      marginLeft: 10,
    },
  });

  const [menuVisible, setMenuVisible] = useState(false);

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      
      {documents.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="document-text-outline" size={60} color={theme.text + '40'} />
          <Text style={styles.emptyText}>{t('noDocumentsYet')}</Text>
          <Text style={styles.emptyText}>{t('createNewDocument')}</Text>
        </View>
      ) : (
        <FlatList
          data={documents}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={{ flexGrow: 1 }}
        />
      )}
      
      {menuVisible && (
        <View style={styles.actionMenu}>
          <TouchableOpacity 
            style={styles.actionMenuItem}
            onPress={() => {
              setMenuVisible(false);
              navigation.navigate('DocumentGenerator', { mode: 'template' });
            }}
          >
            <Ionicons name="list-outline" size={24} color={theme.primary} />
            <Text style={styles.actionMenuItemText}>{t('templates')}</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionMenuItem}
            onPress={() => {
              setMenuVisible(false);
              navigation.navigate('DocumentGenerator', { mode: 'description' });
            }}
          >
            <Ionicons name="create-outline" size={24} color={theme.primary} />
            <Text style={styles.actionMenuItemText}>{t('createFromDescription')}</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionMenuItem}
            onPress={() => {
              setMenuVisible(false);
              navigation.navigate('DocumentAnalysis');
            }}
          >
            <Ionicons name="scan-outline" size={24} color={theme.primary} />
            <Text style={styles.actionMenuItemText}>{t('analyzeDocument')}</Text>
          </TouchableOpacity>
        </View>
      )}
      
      <TouchableOpacity 
        style={styles.fab} 
        onPress={() => setMenuVisible(!menuVisible)}
      >
        <Ionicons 
          name={menuVisible ? "close" : "add"} 
          size={30} 
          style={styles.fabIcon} 
        />
      </TouchableOpacity>
    </View>
  );
};

export default DocumentListScreen;
