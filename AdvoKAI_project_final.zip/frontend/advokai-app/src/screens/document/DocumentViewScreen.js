import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Share } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const DocumentViewScreen = ({ route, navigation }) => {
  const { documentId, title } = route.params;
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [document, setDocument] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [menuVisible, setMenuVisible] = useState(false);

  useEffect(() => {
    navigation.setOptions({
      title: title,
      headerRight: () => (
        <TouchableOpacity 
          style={{ marginRight: 15 }}
          onPress={() => setMenuVisible(!menuVisible)}
        >
          <Ionicons name="ellipsis-vertical" size={24} color={theme.text} />
        </TouchableOpacity>
      ),
    });
    
    fetchDocument();
  }, [documentId]);

  const fetchDocument = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('id', documentId)
        .single();

      if (error) throw error;
      
      setDocument(data);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Check out this document: ${document.title}`,
        title: document.title,
      });
    } catch (error) {
      setError(error.message);
    }
  };

  const handleSign = () => {
    // In a real app, this would navigate to a signing screen
    // or initiate the BankID signing process
    navigation.navigate('DocumentSign', { documentId });
  };

  const handleDelete = async () => {
    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('documents')
        .delete()
        .eq('id', documentId);

      if (error) throw error;
      
      navigation.goBack();
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return theme.success;
    if (score >= 50) return theme.warning;
    return theme.error;
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    content: {
      padding: 20,
    },
    documentHeader: {
      marginBottom: 20,
    },
    documentTitle: {
      fontSize: 24,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 10,
    },
    documentType: {
      fontSize: 16,
      color: theme.text + '80',
      marginBottom: 5,
    },
    documentDate: {
      fontSize: 14,
      color: theme.text + '60',
      marginBottom: 10,
    },
    securityScoreContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 5,
    },
    securityScoreText: {
      fontSize: 14,
      marginLeft: 5,
    },
    signedBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },
    signedText: {
      fontSize: 14,
      color: theme.success,
      marginLeft: 5,
    },
    documentContent: {
      backgroundColor: theme.card,
      padding: 15,
      borderRadius: 5,
      marginBottom: 20,
    },
    documentContentText: {
      fontSize: 16,
      color: theme.text,
      lineHeight: 24,
    },
    actionButton: {
      backgroundColor: theme.primary,
      padding: 15,
      borderRadius: 5,
      alignItems: 'center',
      marginBottom: 15,
      flexDirection: 'row',
      justifyContent: 'center',
    },
    actionButtonText: {
      color: 'white',
      fontWeight: 'bold',
      fontSize: 16,
      marginLeft: 10,
    },
    deleteButton: {
      backgroundColor: theme.error,
    },
    menuContainer: {
      position: 'absolute',
      top: 60,
      right: 10,
      backgroundColor: theme.card,
      borderRadius: 5,
      elevation: 5,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 3,
      zIndex: 1000,
    },
    menuItem: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    menuItemText: {
      color: theme.text,
      marginLeft: 10,
    },
    menuItemDelete: {
      color: theme.error,
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (!document) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 20 }]}>
        <Text style={{ color: theme.text, textAlign: 'center' }}>
          {error || t('documentNotFound')}
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {menuVisible && (
        <View style={styles.menuContainer}>
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => {
              setMenuVisible(false);
              handleShare();
            }}
          >
            <Ionicons name="share-outline" size={24} color={theme.primary} />
            <Text style={styles.menuItemText}>{t('share')}</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => {
              setMenuVisible(false);
              // In a real app, this would download the document
            }}
          >
            <Ionicons name="download-outline" size={24} color={theme.primary} />
            <Text style={styles.menuItemText}>{t('download')}</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.menuItem}
            onPress={() => {
              setMenuVisible(false);
              handleDelete();
            }}
          >
            <Ionicons name="trash-outline" size={24} color={theme.error} />
            <Text style={[styles.menuItemText, styles.menuItemDelete]}>{t('delete')}</Text>
          </TouchableOpacity>
        </View>
      )}
      
      <ScrollView style={styles.content}>
        <View style={styles.documentHeader}>
          <Text style={styles.documentTitle}>{document.title}</Text>
          <Text style={styles.documentType}>{document.document_type}</Text>
          <Text style={styles.documentDate}>
            {t('created')}: {new Date(document.created_at).toLocaleDateString()}
          </Text>
          <Text style={styles.documentDate}>
            {t('updated')}: {new Date(document.updated_at).toLocaleDateString()}
          </Text>
          
          <View style={styles.securityScoreContainer}>
            <Ionicons 
              name="shield-checkmark-outline" 
              size={20} 
              color={getScoreColor(document.security_score)} 
            />
            <Text style={[
              styles.securityScoreText,
              { color: getScoreColor(document.security_score) }
            ]}>
              {t('securityScore')}: {document.security_score}%
            </Text>
          </View>
          
          {document.is_signed && (
            <View style={styles.signedBadge}>
              <Ionicons name="checkmark-circle" size={20} color={theme.success} />
              <Text style={styles.signedText}>{t('signed')}</Text>
            </View>
          )}
        </View>
        
        <View style={styles.documentContent}>
          <Text style={styles.documentContentText}>
            {document.content}
          </Text>
        </View>
        
        {!document.is_signed && (
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleSign}
          >
            <Ionicons name="create-outline" size={24} color="white" />
            <Text style={styles.actionButtonText}>{t('sign')}</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => navigation.navigate('DocumentAnalysis', { documentId })}
        >
          <Ionicons name="analytics-outline" size={24} color="white" />
          <Text style={styles.actionButtonText}>{t('analyze')}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteButton]}
          onPress={handleDelete}
        >
          <Ionicons name="trash-outline" size={24} color="white" />
          <Text style={styles.actionButtonText}>{t('delete')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default DocumentViewScreen;
