import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase'; // Assuming supabase client is configured for API calls
import { Ionicons } from '@expo/vector-icons';

const DocumentSignScreen = ({ route, navigation }) => {
  const { documentId } = route.params;
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key, params) => getTranslation(key, language, params);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [signingStatus, setSigningStatus] = useState('pending'); // 'pending', 'initiated', 'success', 'failed', 'cancelled'
  const [criiptoUrl, setCriiptoUrl] = useState(null);
  const [signatureRequestId, setSignatureRequestId] = useState(null);

  const initiateSigning = async () => {
    setLoading(true);
    setError('');
    try {
      // In a real application, you would get recipient details from the user or document metadata
      const recipients = [{ email: 'user@example.com', name: 'Test User', signature_method: 'bankid_no' }]; // Placeholder

      const { data, error: apiError } = await supabase.functions.invoke('create-signature-request', {
        body: { documentId, recipients }
      });

      if (apiError) throw apiError;

      if (data && data.signatureRequest && data.signatureRequest.id) {
        setSignatureRequestId(data.signatureRequest.id);
        // Assuming the backend returns a URL for BankID or a way to get it
        // For now, we'll simulate this part and move to a status check
        setSigningStatus('initiated');
        // If Criipto provides a direct URL to redirect the user:
        // setCriiptoUrl(data.criiptoUrl); 
        // Or, if using an in-app WebView for BankID, prepare that.
        // This example will simplify to polling for status.
        pollSignatureStatus(data.signatureRequest.id);
      } else {
        throw new Error(data.message || 'Failed to initiate signing process.');
      }
    } catch (err) {
      setError(err.message || 'An unexpected error occurred.');
      setSigningStatus('failed');
    } finally {
      setLoading(false);
    }
  };

  const pollSignatureStatus = async (reqId) => {
    if (!reqId) return;
    setLoading(true);
    try {
      const { data, error: pollError } = await supabase.functions.invoke('check-signature-status', {
        body: { documentId, signatureRequestId: reqId }
      });

      if (pollError) throw pollError;

      if (data && data.status) {
        setSigningStatus(data.status);
        if (data.status === 'pending' || data.status === 'initiated' || data.status === 'signing') {
          // Continue polling if not completed or failed
          setTimeout(() => pollSignatureStatus(reqId), 5000); // Poll every 5 seconds
        } else {
          setLoading(false);
        }
      } else {
        throw new Error('Could not retrieve signature status.');
      }
    } catch (err) {
      setError(err.message || 'Error polling signature status.');
      // Don't set status to failed here, as polling might just be temporarily interrupted
      setLoading(false); // Stop loading indicator on poll error to allow retry or manual check
    }
  };

  useEffect(() => {
    initiateSigning();
  }, [documentId]);

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: theme.background,
      padding: 20,
    },
    title: {
      fontSize: 22,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 20,
      textAlign: 'center',
    },
    text: {
      fontSize: 16,
      color: theme.text,
      textAlign: 'center',
      marginBottom: 15,
    },
    statusText: {
      fontSize: 18,
      fontWeight: 'bold',
      color: theme.primary,
      marginBottom: 20,
    },
    errorText: {
      fontSize: 16,
      color: theme.error,
      textAlign: 'center',
      marginBottom: 20,
    },
    button: {
      backgroundColor: theme.primary,
      paddingVertical: 12,
      paddingHorizontal: 30,
      borderRadius: 5,
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 10,
    },
    buttonText: {
      color: 'white',
      fontSize: 16,
      fontWeight: 'bold',
      marginLeft: 10,
    }
  });

  if (loading && !signatureRequestId) { // Initial loading for initiation
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={[styles.text, { marginTop: 10 }]}>{t('initiatingSigningProcess')}</Text>
      </View>
    );
  }
  
  let statusMessage = '';
  let statusIcon = null;

  switch (signingStatus) {
    case 'pending':
      statusMessage = t('signingStatusPending');
      statusIcon = <ActivityIndicator size="small" color={theme.primary} style={{ marginRight: 10}}/>;
      break;
    case 'initiated':
      statusMessage = t('signingStatusInitiated');
      statusIcon = <Ionicons name="information-circle-outline" size={24} color={theme.primary} style={{ marginRight: 10}}/>;
      // Here you might redirect to criiptoUrl if available and using WebView or external browser
      break;
    case 'signing': // Assuming backend might update to this status during Criipto interaction
      statusMessage = t('signingInProgressAtBankID');
      statusIcon = <ActivityIndicator size="small" color={theme.primary} style={{ marginRight: 10}}/>;
      break;
    case 'completed': // Changed from 'success' to match backend
      statusMessage = t('signingStatusSuccess');
      statusIcon = <Ionicons name="checkmark-circle-outline" size={24} color={theme.success} style={{ marginRight: 10}}/>;
      break;
    case 'failed':
      statusMessage = t('signingStatusFailed');
      statusIcon = <Ionicons name="close-circle-outline" size={24} color={theme.error} style={{ marginRight: 10}}/>;
      break;
    case 'cancelled':
      statusMessage = t('signingStatusCancelled');
      statusIcon = <Ionicons name="alert-circle-outline" size={24} color={theme.warning} style={{ marginRight: 10}}/>;
      break;
    default:
      statusMessage = t('signingStatusUnknown');
      statusIcon = <Ionicons name="help-circle-outline" size={24} color={theme.text} style={{ marginRight: 10}}/>;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{t('documentSigning')}</Text>
      {error && <Text style={styles.errorText}>{error}</Text>}
      
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 20 }}>
        {statusIcon}
        <Text style={styles.statusText}>{statusMessage}</Text>
      </View>

      {loading && (signingStatus === 'pending' || signingStatus === 'initiated' || signingStatus === 'signing') && (
        <View style={{alignItems: 'center'}}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={[styles.text, { marginTop: 10 }]}>{t('checkingSignatureStatus')}</Text>
        </View>
      )}

      {(signingStatus === 'failed' || signingStatus === 'cancelled' || error) && (
        <TouchableOpacity style={styles.button} onPress={initiateSigning} disabled={loading}>
          <Ionicons name="refresh-outline" size={20} color="white" />
          <Text style={styles.buttonText}>{t('tryAgain')}</Text>
        </TouchableOpacity>
      )}

      {(signingStatus === 'completed') && (
        <TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back-outline" size={20} color="white" />
          <Text style={styles.buttonText}>{t('backToDocument')}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

export default DocumentSignScreen;

