import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, ActivityIndicator, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const ChatConversationScreen = ({ route, navigation }) => {
  const { chatId, title } = route.params;
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [attachments, setAttachments] = useState([]);
  
  const flatListRef = useRef(null);

  useEffect(() => {
    navigation.setOptions({
      title: title,
    });
    
    fetchMessages();
    
    // Subscribe to new messages
    const subscription = supabase
      .channel('chat_messages')
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'messages',
        filter: `chat_id=eq.${chatId}`
      }, (payload) => {
        setMessages(prevMessages => [...prevMessages, payload.new]);
      })
      .subscribe();
      
    return () => {
      subscription.unsubscribe();
    };
  }, [chatId]);

  const fetchMessages = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('chat_id', chatId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      
      setMessages(data || []);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async () => {
    if (inputText.trim() === '' && attachments.length === 0) return;
    
    try {
      setSending(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      // Upload attachments if any
      const uploadedAttachments = [];
      for (const attachment of attachments) {
        const fileExt = attachment.name.split('.').pop();
        const filePath = `${user.id}/${chatId}/${Date.now()}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('attachments')
          .upload(filePath, attachment);
          
        if (uploadError) throw uploadError;
        
        uploadedAttachments.push({
          path: filePath,
          type: attachment.mimeType,
          name: attachment.name
        });
      }

      // Insert message
      const { error } = await supabase
        .from('messages')
        .insert([
          { 
            chat_id: chatId,
            user_id: user.id,
            content: inputText.trim(),
            attachments: uploadedAttachments,
            is_user: true
          }
        ]);

      if (error) throw error;
      
      // Update chat's last message
      await supabase
        .from('chats')
        .update({ 
          last_message: inputText.trim() || t('attachment'),
          updated_at: new Date().toISOString()
        })
        .eq('id', chatId);
        
      setInputText('');
      setAttachments([]);
      
      // Simulate AI response (in a real app, this would be handled by a backend service)
      setTimeout(async () => {
        await supabase
          .from('messages')
          .insert([
            { 
              chat_id: chatId,
              user_id: null,
              content: 'Dette er et automatisk svar fra KAI. I en faktisk implementasjon ville dette vært et svar generert av OpenAI API basert på din melding og juridisk kontekst.',
              is_user: false
            }
          ]);
      }, 1000);
      
    } catch (error) {
      setError(error.message);
    } finally {
      setSending(false);
    }
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true
      });
      
      if (result.canceled) return;
      
      setAttachments([...attachments, result.assets[0]]);
    } catch (error) {
      setError(error.message);
    }
  };

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.8,
      });
      
      if (result.canceled) return;
      
      setAttachments([...attachments, {
        ...result.assets[0],
        name: `image_${Date.now()}.jpg`,
        mimeType: 'image/jpeg'
      }]);
    } catch (error) {
      setError(error.message);
    }
  };

  const removeAttachment = (index) => {
    const newAttachments = [...attachments];
    newAttachments.splice(index, 1);
    setAttachments(newAttachments);
  };

  const renderMessage = ({ item }) => (
    <View style={[
      styles.messageContainer,
      item.is_user ? styles.userMessageContainer : styles.aiMessageContainer
    ]}>
      <View style={[
        styles.messageBubble,
        item.is_user ? styles.userMessageBubble : styles.aiMessageBubble
      ]}>
        <Text style={styles.messageText}>{item.content}</Text>
        
        {item.attachments && item.attachments.length > 0 && (
          <View style={styles.attachmentsContainer}>
            {item.attachments.map((attachment, index) => (
              <View key={index} style={styles.attachmentItem}>
                <Ionicons 
                  name={attachment.type.startsWith('image') ? 'image-outline' : 'document-outline'} 
                  size={20} 
                  color={item.is_user ? 'white' : theme.primary} 
                />
                <Text style={[
                  styles.attachmentName,
                  { color: item.is_user ? 'white' : theme.text }
                ]} numberOfLines={1}>
                  {attachment.name}
                </Text>
              </View>
            ))}
          </View>
        )}
        
        <Text style={[
          styles.messageTime,
          { color: item.is_user ? 'rgba(255,255,255,0.7)' : theme.text + '60' }
        ]}>
          {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    </View>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    messagesList: {
      flex: 1,
      padding: 10,
    },
    messageContainer: {
      marginVertical: 5,
      flexDirection: 'row',
    },
    userMessageContainer: {
      justifyContent: 'flex-end',
    },
    aiMessageContainer: {
      justifyContent: 'flex-start',
    },
    messageBubble: {
      maxWidth: '80%',
      padding: 12,
      borderRadius: 18,
    },
    userMessageBubble: {
      backgroundColor: theme.primary,
      borderBottomRightRadius: 5,
    },
    aiMessageBubble: {
      backgroundColor: theme.card,
      borderBottomLeftRadius: 5,
    },
    messageText: {
      fontSize: 16,
      color: theme.text,
    },
    messageTime: {
      fontSize: 12,
      alignSelf: 'flex-end',
      marginTop: 5,
    },
    inputContainer: {
      flexDirection: 'row',
      padding: 10,
      borderTopWidth: 1,
      borderTopColor: theme.border,
      backgroundColor: theme.background,
    },
    input: {
      flex: 1,
      backgroundColor: theme.card,
      borderRadius: 20,
      paddingHorizontal: 15,
      paddingVertical: 10,
      marginRight: 10,
      color: theme.text,
    },
    sendButton: {
      width: 44,
      height: 44,
      borderRadius: 22,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
    },
    attachButton: {
      width: 44,
      height: 44,
      borderRadius: 22,
      backgroundColor: theme.card,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 10,
    },
    attachmentsPreview: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      padding: 10,
      backgroundColor: theme.background,
    },
    attachmentPreview: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      borderRadius: 15,
      padding: 5,
      margin: 5,
    },
    attachmentPreviewText: {
      color: theme.text,
      marginHorizontal: 5,
      maxWidth: 150,
    },
    removeAttachment: {
      marginLeft: 5,
    },
    attachmentsContainer: {
      marginTop: 5,
    },
    attachmentItem: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 5,
    },
    attachmentName: {
      marginLeft: 5,
      fontSize: 14,
      flex: 1,
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
      keyboardVerticalOffset={90}
    >
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      
      {loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={theme.primary} />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.messagesList}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
          onLayout={() => flatListRef.current?.scrollToEnd({ animated: true })}
        />
      )}
      
      {attachments.length > 0 && (
        <View style={styles.attachmentsPreview}>
          {attachments.map((attachment, index) => (
            <View key={index} style={styles.attachmentPreview}>
              <Ionicons 
                name={attachment.mimeType?.startsWith('image') ? 'image-outline' : 'document-outline'} 
                size={20} 
                color={theme.text} 
              />
              <Text style={styles.attachmentPreviewText} numberOfLines={1}>
                {attachment.name}
              </Text>
              <TouchableOpacity onPress={() => removeAttachment(index)} style={styles.removeAttachment}>
                <Ionicons name="close-circle" size={20} color={theme.error} />
              </TouchableOpacity>
            </View>
          ))}
        </View>
      )}
      
      <View style={styles.inputContainer}>
        <TouchableOpacity style={styles.attachButton} onPress={pickDocument}>
          <Ionicons name="document-outline" size={24} color={theme.text} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.attachButton} onPress={pickImage}>
          <Ionicons name="image-outline" size={24} color={theme.text} />
        </TouchableOpacity>
        <TextInput
          style={styles.input}
          placeholder={t('typeMessage')}
          placeholderTextColor={theme.text + '60'}
          value={inputText}
          onChangeText={setInputText}
          multiline
        />
        <TouchableOpacity 
          style={[
            styles.sendButton,
            { opacity: (inputText.trim() === '' && attachments.length === 0) || sending ? 0.7 : 1 }
          ]} 
          onPress={sendMessage}
          disabled={(inputText.trim() === '' && attachments.length === 0) || sending}
        >
          {sending ? (
            <ActivityIndicator size="small" color="white" />
          ) : (
            <Ionicons name="send" size={20} color="white" />
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default ChatConversationScreen;
