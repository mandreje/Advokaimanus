import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../utils/ThemeContext';
import { useLanguage, getTranslation } from '../../i18n/LanguageContext';
import { supabase } from '../../utils/supabase';

const ChatListScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { language } = useLanguage();
  const t = (key) => getTranslation(key, language);
  
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchChats();
  }, []);

  const fetchChats = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('chats')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      
      setChats(data || []);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const createNewChat = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('chats')
        .insert([
          { 
            user_id: user.id,
            title: t('newChat'),
            last_message: '',
          }
        ])
        .select();

      if (error) throw error;
      
      if (data && data.length > 0) {
        navigation.navigate('ChatConversation', { 
          chatId: data[0].id,
          title: data[0].title
        });
      }
    } catch (error) {
      setError(error.message);
    }
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.chatItem}
      onPress={() => navigation.navigate('ChatConversation', { 
        chatId: item.id,
        title: item.title
      })}
    >
      <View style={styles.chatIcon}>
        <Ionicons name="chatbubble-ellipses-outline" size={24} color={theme.primary} />
      </View>
      <View style={styles.chatInfo}>
        <Text style={styles.chatTitle}>{item.title}</Text>
        <Text style={styles.chatLastMessage} numberOfLines={1}>
          {item.last_message || t('noMessages')}
        </Text>
      </View>
      <Text style={styles.chatDate}>
        {new Date(item.updated_at).toLocaleDateString()}
      </Text>
    </TouchableOpacity>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    header: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    title: {
      fontSize: 20,
      fontWeight: 'bold',
      color: theme.text,
    },
    chatItem: {
      flexDirection: 'row',
      padding: 15,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
      alignItems: 'center',
    },
    chatIcon: {
      width: 50,
      height: 50,
      borderRadius: 25,
      backgroundColor: theme.card,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 15,
    },
    chatInfo: {
      flex: 1,
    },
    chatTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: theme.text,
      marginBottom: 5,
    },
    chatLastMessage: {
      fontSize: 14,
      color: theme.text + '80',
    },
    chatDate: {
      fontSize: 12,
      color: theme.text + '60',
    },
    fab: {
      position: 'absolute',
      width: 60,
      height: 60,
      borderRadius: 30,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
      right: 20,
      bottom: 20,
      elevation: 5,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 3,
    },
    fabIcon: {
      color: 'white',
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 20,
    },
    emptyText: {
      fontSize: 16,
      color: theme.text + '80',
      textAlign: 'center',
      marginTop: 10,
    },
    errorText: {
      color: theme.error,
      textAlign: 'center',
      margin: 10,
    },
  });

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      
      {chats.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="chatbubble-ellipses-outline" size={60} color={theme.text + '40'} />
          <Text style={styles.emptyText}>{t('noChatsYet')}</Text>
          <Text style={styles.emptyText}>{t('startNewChat')}</Text>
        </View>
      ) : (
        <FlatList
          data={chats}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={{ flexGrow: 1 }}
        />
      )}
      
      <TouchableOpacity style={styles.fab} onPress={createNewChat}>
        <Ionicons name="add" size={30} style={styles.fabIcon} />
      </TouchableOpacity>
    </View>
  );
};

export default ChatListScreen;
