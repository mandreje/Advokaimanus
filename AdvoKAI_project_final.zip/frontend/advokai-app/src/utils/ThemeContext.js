import React, { createContext, useState, useContext, useEffect } from 'react';
import { useColorScheme } from 'react-native';

// Define theme colors
const lightTheme = {
  primary: '#0047AB', // Trustworthy blue
  secondary: '#FFD700', // Gold from KAI character
  background: '#FFFFFF',
  card: '#F8F9FA',
  text: '#333333',
  border: '#E0E0E0',
  notification: '#FF3B30',
  error: '#FF3B30',
  success: '#34C759',
  warning: '#FF9500',
  info: '#007AFF',
};

const darkTheme = {
  primary: '#0047AB', // Keep the same primary color for brand consistency
  secondary: '#FFD700', // Keep the same secondary color for brand consistency
  background: '#121212',
  card: '#1E1E1E',
  text: '#F5F5F5',
  border: '#2C2C2C',
  notification: '#FF453A',
  error: '#FF453A',
  success: '#30D158',
  warning: '#FF9F0A',
  info: '#0A84FF',
};

// Create the context
const ThemeContext = createContext();

// Create a provider component
export const ThemeProvider = ({ children }) => {
  const colorScheme = useColorScheme();
  const [theme, setTheme] = useState(colorScheme === 'dark' ? darkTheme : lightTheme);
  const [isDark, setIsDark] = useState(colorScheme === 'dark');

  // Update theme when system theme changes
  useEffect(() => {
    setTheme(colorScheme === 'dark' ? darkTheme : lightTheme);
    setIsDark(colorScheme === 'dark');
  }, [colorScheme]);

  // Toggle theme manually
  const toggleTheme = () => {
    setIsDark(!isDark);
    setTheme(isDark ? lightTheme : darkTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Create a custom hook to use the theme context
export const useTheme = () => useContext(ThemeContext);
