const aiService = require('./aiService');
const ragService = require('./ragService');
const supabase = require('../utils/supabase');

// Generate document from template
const generateFromTemplate = async (templateId, variables, userId, jurisdiction) => {
  try {
    // Get template from Supabase
    const { data: template, error: templateError } = await supabase
      .from('document_templates')
      .select('*')
      .eq('id', templateId)
      .single();
      
    if (templateError) {
      throw templateError;
    }
    
    if (!template) {
      throw new Error('Template not found');
    }
    
    // Replace variables in template
    let content = template.content;
    
    for (const [key, value] of Object.entries(variables)) {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      content = content.replace(regex, value);
    }
    
    // Calculate security score
    const { score, evaluation } = await aiService.calculateDocumentSecurityScore(
      content, 
      jurisdiction, 
      template.document_type
    );
    
    // Extract structured information
    const structuredData = await aiService.extractStructuredInformation(
      content,
      template.document_type
    );
    
    // Create document in Supabase
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .insert([
        {
          user_id: userId,
          title: template.title,
          content,
          type: template.document_type,
          template_id: templateId,
          jurisdiction,
          security_score: score,
          security_evaluation: evaluation,
          structured_data: structuredData,
          variables,
        }
      ])
      .select();
      
    if (documentError) {
      throw documentError;
    }
    
    // Create vector store for document
    await ragService.createVectorStore(document[0], userId);
    
    return document[0];
  } catch (error) {
    console.error('Error generating document from template:', error);
    throw error;
  }
};

// Generate document from description
const generateFromDescription = async (description, documentType, userId, jurisdiction) => {
  try {
    // Generate document content
    const content = await aiService.generateDocumentFromDescription(
      description,
      jurisdiction,
      documentType
    );
    
    // Calculate security score
    const { score, evaluation } = await aiService.calculateDocumentSecurityScore(
      content, 
      jurisdiction, 
      documentType
    );
    
    // Extract structured information
    const structuredData = await aiService.extractStructuredInformation(
      content,
      documentType
    );
    
    // Create document in Supabase
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .insert([
        {
          user_id: userId,
          title: `${documentType} - ${new Date().toISOString().split('T')[0]}`,
          content,
          type: documentType,
          template_id: null,
          jurisdiction,
          security_score: score,
          security_evaluation: evaluation,
          structured_data: structuredData,
          variables: { description },
        }
      ])
      .select();
      
    if (documentError) {
      throw documentError;
    }
    
    // Create vector store for document
    await ragService.createVectorStore(document[0], userId);
    
    return document[0];
  } catch (error) {
    console.error('Error generating document from description:', error);
    throw error;
  }
};

// Analyze uploaded document
const analyzeUploadedDocument = async (content, documentType, userId, jurisdiction) => {
  try {
    // Analyze document
    const analysis = await aiService.analyzeDocument(
      content,
      jurisdiction
    );
    
    // Calculate security score
    const { score, evaluation } = await aiService.calculateDocumentSecurityScore(
      content, 
      jurisdiction, 
      documentType
    );
    
    // Extract structured information
    const structuredData = await aiService.extractStructuredInformation(
      content,
      documentType
    );
    
    // Create document in Supabase
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .insert([
        {
          user_id: userId,
          title: `${documentType} Analysis - ${new Date().toISOString().split('T')[0]}`,
          content,
          type: documentType,
          template_id: null,
          jurisdiction,
          security_score: score,
          security_evaluation: evaluation,
          analysis,
          structured_data: structuredData,
        }
      ])
      .select();
      
    if (documentError) {
      throw documentError;
    }
    
    // Create vector store for document
    await ragService.createVectorStore(document[0], userId);
    
    return {
      document: document[0],
      analysis,
      security_score: score,
      security_evaluation: evaluation,
      structured_data: structuredData,
    };
  } catch (error) {
    console.error('Error analyzing uploaded document:', error);
    throw error;
  }
};

// Get document templates
const getDocumentTemplates = async (jurisdiction, documentType) => {
  try {
    let query = supabase
      .from('document_templates')
      .select('*');
      
    if (jurisdiction) {
      query = query.eq('jurisdiction', jurisdiction);
    }
    
    if (documentType) {
      query = query.eq('document_type', documentType);
    }
    
    const { data, error } = await query;
    
    if (error) {
      throw error;
    }
    
    return data || [];
  } catch (error) {
    console.error('Error getting document templates:', error);
    throw error;
  }
};

// Get document template variables
const getTemplateVariables = async (templateId) => {
  try {
    const { data: template, error } = await supabase
      .from('document_templates')
      .select('content, variables')
      .eq('id', templateId)
      .single();
      
    if (error) {
      throw error;
    }
    
    if (!template) {
      throw new Error('Template not found');
    }
    
    // If variables are already defined, return them
    if (template.variables && Object.keys(template.variables).length > 0) {
      return template.variables;
    }
    
    // Otherwise, extract variables from content
    const variableRegex = /\{\{([^}]+)\}\}/g;
    const matches = template.content.matchAll(variableRegex);
    const variables = {};
    
    for (const match of matches) {
      variables[match[1]] = '';
    }
    
    return variables;
  } catch (error) {
    console.error('Error getting template variables:', error);
    throw error;
  }
};

// Create document version
const createDocumentVersion = async (documentId, content, userId) => {
  try {
    // Get current document
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError) {
      throw documentError;
    }
    
    if (!document) {
      throw new Error('Document not found');
    }
    
    // Create document version
    const { data: version, error: versionError } = await supabase
      .from('document_versions')
      .insert([
        {
          document_id: documentId,
          content: document.content,
          version_number: document.version || 1,
          created_by: userId,
        }
      ])
      .select();
      
    if (versionError) {
      throw versionError;
    }
    
    // Update document with new content and increment version
    const { data: updatedDocument, error: updateError } = await supabase
      .from('documents')
      .update({
        content,
        version: (document.version || 1) + 1,
        updated_at: new Date().toISOString(),
      })
      .eq('id', documentId)
      .select();
      
    if (updateError) {
      throw updateError;
    }
    
    // Update vector store
    await ragService.createVectorStore(updatedDocument[0], userId);
    
    return {
      document: updatedDocument[0],
      version: version[0],
    };
  } catch (error) {
    console.error('Error creating document version:', error);
    throw error;
  }
};

// Get document versions
const getDocumentVersions = async (documentId, userId) => {
  try {
    // Check if document belongs to user
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('id')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !document) {
      throw new Error('Document not found or access denied');
    }
    
    // Get document versions
    const { data, error } = await supabase
      .from('document_versions')
      .select('*')
      .eq('document_id', documentId)
      .order('version_number', { ascending: false });
      
    if (error) {
      throw error;
    }
    
    return data || [];
  } catch (error) {
    console.error('Error getting document versions:', error);
    throw error;
  }
};

module.exports = {
  generateFromTemplate,
  generateFromDescription,
  analyzeUploadedDocument,
  getDocumentTemplates,
  getTemplateVariables,
  createDocumentVersion,
  getDocumentVersions,
};
