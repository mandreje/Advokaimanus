const supabase = require('../utils/supabase');
const axios = require('axios');
const crypto = require('crypto');

// Initialize Criipto configuration
const criiptoConfig = {
  clientId: process.env.CRIIPTO_CLIENT_ID,
  clientSecret: process.env.CRIIPTO_CLIENT_SECRET,
  redirectUri: process.env.CRIIPTO_REDIRECT_URI,
  authorizationEndpoint: 'https://api.criipto.com/oauth/authorize',
  tokenEndpoint: 'https://api.criipto.com/oauth/token',
};

// Generate signature request
const generateSignatureRequest = async (documentId, userId, recipients) => {
  try {
    // Get document
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !document) {
      throw new Error('Document not found or access denied');
    }
    
    // Create signature request
    const { data: signatureRequest, error: requestError } = await supabase
      .from('signature_requests')
      .insert([
        {
          document_id: documentId,
          created_by: userId,
          status: 'pending',
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
        }
      ])
      .select();
      
    if (requestError) {
      throw requestError;
    }
    
    // Add recipients
    const recipientPromises = recipients.map(recipient => {
      return supabase
        .from('signature_recipients')
        .insert([
          {
            signature_request_id: signatureRequest[0].id,
            email: recipient.email,
            name: recipient.name,
            order: recipient.order || 1,
            status: 'pending',
            signature_method: recipient.signature_method || 'bankid',
          }
        ]);
    });
    
    await Promise.all(recipientPromises);
    
    // Generate signing URLs for each recipient
    const recipientsWithUrls = await Promise.all(recipients.map(async (recipient) => {
      const signingToken = crypto.randomBytes(32).toString('hex');
      
      // Store signing token
      await supabase
        .from('signature_tokens')
        .insert([
          {
            signature_request_id: signatureRequest[0].id,
            email: recipient.email,
            token: signingToken,
            expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
          }
        ]);
      
      return {
        ...recipient,
        signing_url: `${process.env.APP_URL}/sign/${signingToken}`,
      };
    }));
    
    return {
      signature_request: signatureRequest[0],
      recipients: recipientsWithUrls,
    };
  } catch (error) {
    console.error('Error generating signature request:', error);
    throw error;
  }
};

// Get signature request
const getSignatureRequest = async (requestId, userId) => {
  try {
    // Get signature request
    const { data: signatureRequest, error: requestError } = await supabase
      .from('signature_requests')
      .select(`
        *,
        document:document_id(*),
        recipients:signature_recipients(*)
      `)
      .eq('id', requestId)
      .single();
      
    if (requestError) {
      throw requestError;
    }
    
    // Check if user has access to this request
    if (signatureRequest.created_by !== userId && !signatureRequest.recipients.some(r => r.email === userId)) {
      throw new Error('Access denied');
    }
    
    return signatureRequest;
  } catch (error) {
    console.error('Error getting signature request:', error);
    throw error;
  }
};

// Verify signature token
const verifySignatureToken = async (token) => {
  try {
    // Get token
    const { data: tokenData, error: tokenError } = await supabase
      .from('signature_tokens')
      .select(`
        *,
        signature_request:signature_request_id(
          *,
          document:document_id(*),
          recipients:signature_recipients(*)
        )
      `)
      .eq('token', token)
      .single();
      
    if (tokenError) {
      throw tokenError;
    }
    
    // Check if token is expired
    if (new Date(tokenData.expires_at) < new Date()) {
      throw new Error('Signature token has expired');
    }
    
    // Check if signature request is still valid
    if (tokenData.signature_request.status !== 'pending') {
      throw new Error('Signature request is no longer valid');
    }
    
    return tokenData;
  } catch (error) {
    console.error('Error verifying signature token:', error);
    throw error;
  }
};

// Generate BankID authentication URL
const generateBankIDAuthUrl = async (token, country = 'NO') => {
  try {
    // Create state parameter to track the session
    const state = crypto.randomBytes(16).toString('hex');
    
    // Store state in Supabase
    await supabase
      .from('auth_states')
      .insert([
        {
          state,
          token,
          expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes from now
        }
      ]);
    
    // Determine BankID acr_values based on country
    let acrValues;
    switch (country) {
      case 'NO':
        acrValues = 'urn:criipto:oidc:method:sbid-no';
        break;
      case 'SE':
        acrValues = 'urn:criipto:oidc:method:sbid-se';
        break;
      case 'DK':
        acrValues = 'urn:criipto:oidc:method:nemid';
        break;
      default:
        acrValues = 'urn:criipto:oidc:method:sbid-no';
    }
    
    // Generate authorization URL
    const authUrl = `${criiptoConfig.authorizationEndpoint}?` +
      `client_id=${encodeURIComponent(criiptoConfig.clientId)}` +
      `&redirect_uri=${encodeURIComponent(criiptoConfig.redirectUri)}` +
      `&response_type=code` +
      `&scope=openid profile` +
      `&state=${encodeURIComponent(state)}` +
      `&acr_values=${encodeURIComponent(acrValues)}`;
    
    return {
      auth_url: authUrl,
      state,
    };
  } catch (error) {
    console.error('Error generating BankID auth URL:', error);
    throw error;
  }
};

// Process BankID callback
const processBankIDCallback = async (code, state) => {
  try {
    // Verify state
    const { data: stateData, error: stateError } = await supabase
      .from('auth_states')
      .select('*')
      .eq('state', state)
      .single();
      
    if (stateError) {
      throw new Error('Invalid state parameter');
    }
    
    // Check if state is expired
    if (new Date(stateData.expires_at) < new Date()) {
      throw new Error('Authentication session has expired');
    }
    
    // Exchange code for token
    const tokenResponse = await axios.post(criiptoConfig.tokenEndpoint, {
      grant_type: 'authorization_code',
      code,
      client_id: criiptoConfig.clientId,
      client_secret: criiptoConfig.clientSecret,
      redirect_uri: criiptoConfig.redirectUri,
    });
    
    const { id_token, access_token } = tokenResponse.data;
    
    // Decode ID token (in a real implementation, you would verify the signature)
    const idTokenParts = id_token.split('.');
    const idTokenPayload = JSON.parse(Buffer.from(idTokenParts[1], 'base64').toString());
    
    // Get signature token
    const { data: tokenData, error: tokenError } = await verifySignatureToken(stateData.token);
    
    if (tokenError) {
      throw tokenError;
    }
    
    // Find recipient
    const recipient = tokenData.signature_request.recipients.find(r => r.email === tokenData.email);
    
    if (!recipient) {
      throw new Error('Recipient not found');
    }
    
    // Update recipient status
    await supabase
      .from('signature_recipients')
      .update({
        status: 'signed',
        signed_at: new Date().toISOString(),
        signature_data: {
          id_token,
          user_info: idTokenPayload,
        },
      })
      .eq('id', recipient.id);
    
    // Check if all recipients have signed
    const { data: updatedRecipients, error: recipientsError } = await supabase
      .from('signature_recipients')
      .select('status')
      .eq('signature_request_id', tokenData.signature_request_id);
      
    if (recipientsError) {
      throw recipientsError;
    }
    
    const allSigned = updatedRecipients.every(r => r.status === 'signed');
    
    if (allSigned) {
      // Update signature request status
      await supabase
        .from('signature_requests')
        .update({
          status: 'completed',
          completed_at: new Date().toISOString(),
        })
        .eq('id', tokenData.signature_request_id);
      
      // Update document status
      await supabase
        .from('documents')
        .update({
          is_signed: true,
          signed_at: new Date().toISOString(),
        })
        .eq('id', tokenData.signature_request.document_id);
    }
    
    return {
      success: true,
      user_info: idTokenPayload,
      all_signed: allSigned,
    };
  } catch (error) {
    console.error('Error processing BankID callback:', error);
    throw error;
  }
};

// Send signature request emails
const sendSignatureRequestEmails = async (requestId, userId) => {
  try {
    // Get signature request
    const { data: signatureRequest, error: requestError } = await getSignatureRequest(requestId, userId);
    
    if (requestError) {
      throw requestError;
    }
    
    // Get signing tokens
    const { data: tokens, error: tokensError } = await supabase
      .from('signature_tokens')
      .select('*')
      .eq('signature_request_id', requestId);
      
    if (tokensError) {
      throw tokensError;
    }
    
    // In a real implementation, you would send emails to each recipient
    // For now, we'll just return the signing URLs
    
    const recipientsWithUrls = signatureRequest.recipients.map(recipient => {
      const tokenData = tokens.find(t => t.email === recipient.email);
      return {
        ...recipient,
        signing_url: tokenData ? `${process.env.APP_URL}/sign/${tokenData.token}` : null,
      };
    });
    
    return {
      success: true,
      recipients: recipientsWithUrls,
    };
  } catch (error) {
    console.error('Error sending signature request emails:', error);
    throw error;
  }
};

// Cancel signature request
const cancelSignatureRequest = async (requestId, userId) => {
  try {
    // Check if user has access to this request
    const { data: signatureRequest, error: requestError } = await supabase
      .from('signature_requests')
      .select('*')
      .eq('id', requestId)
      .eq('created_by', userId)
      .single();
      
    if (requestError || !signatureRequest) {
      throw new Error('Signature request not found or access denied');
    }
    
    // Update signature request status
    await supabase
      .from('signature_requests')
      .update({
        status: 'cancelled',
        cancelled_at: new Date().toISOString(),
      })
      .eq('id', requestId);
    
    // Update recipients status
    await supabase
      .from('signature_recipients')
      .update({
        status: 'cancelled',
      })
      .eq('signature_request_id', requestId);
    
    return {
      success: true,
      message: 'Signature request cancelled successfully',
    };
  } catch (error) {
    console.error('Error cancelling signature request:', error);
    throw error;
  }
};

// Get signed document with proof
const getSignedDocumentWithProof = async (documentId, userId) => {
  try {
    // Get document
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !document) {
      throw new Error('Document not found or access denied');
    }
    
    if (!document.is_signed) {
      throw new Error('Document is not signed');
    }
    
    // Get signature request
    const { data: signatureRequest, error: requestError } = await supabase
      .from('signature_requests')
      .select(`
        *,
        recipients:signature_recipients(*)
      `)
      .eq('document_id', documentId)
      .eq('status', 'completed')
      .single();
      
    if (requestError) {
      throw requestError;
    }
    
    // Generate proof document
    // In a real implementation, you would generate a PDF with the document content
    // and signature information
    
    const proof = {
      document_id: document.id,
      document_title: document.title,
      document_content: document.content,
      signed_at: document.signed_at,
      signatures: signatureRequest.recipients.map(recipient => ({
        name: recipient.name,
        email: recipient.email,
        signed_at: recipient.signed_at,
        signature_method: recipient.signature_method,
        signature_data: recipient.signature_data,
      })),
    };
    
    return {
      document,
      proof,
    };
  } catch (error) {
    console.error('Error getting signed document with proof:', error);
    throw error;
  }
};

module.exports = {
  generateSignatureRequest,
  getSignatureRequest,
  verifySignatureToken,
  generateBankIDAuthUrl,
  processBankIDCallback,
  sendSignatureRequestEmails,
  cancelSignatureRequest,
  getSignedDocumentWithProof,
};
