const { Configuration, OpenAIApi } = require('openai');
const supabase = require('../utils/supabase');

// Initialize OpenAI API
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

// Generate embeddings for text
const generateEmbeddings = async (text) => {
  try {
    const response = await openai.createEmbedding({
      model: "text-embedding-ada-002",
      input: text,
    });
    
    return response.data.data[0].embedding;
  } catch (error) {
    console.error('Error generating embeddings:', error);
    throw error;
  }
};

// Generate chat completion
const generateChatCompletion = async (messages, options = {}) => {
  try {
    const response = await openai.createChatCompletion({
      model: options.model || "gpt-4",
      messages,
      temperature: options.temperature || 0.7,
      max_tokens: options.max_tokens || 1000,
      top_p: options.top_p || 1,
      frequency_penalty: options.frequency_penalty || 0,
      presence_penalty: options.presence_penalty || 0,
    });
    
    return response.data.choices[0].message.content;
  } catch (error) {
    console.error('Error generating chat completion:', error);
    throw error;
  }
};

// Generate system prompt for legal assistance
const generateLegalSystemPrompt = (jurisdiction) => {
  const basePrompt = `You are AdvoKAI, an AI legal assistant specialized in providing legal guidance and information. 
You are knowledgeable about laws, regulations, and legal procedures.`;
  
  let jurisdictionPrompt = '';
  
  switch (jurisdiction) {
    case 'NO':
      jurisdictionPrompt = `You are particularly knowledgeable about Norwegian law, including civil law, criminal law, administrative law, and procedural law.
You understand the Norwegian legal system, including the court system, government agencies, and legal procedures.
You can provide information about Norwegian legislation, case law, and legal principles.`;
      break;
    case 'SE':
      jurisdictionPrompt = `You are particularly knowledgeable about Swedish law, including civil law, criminal law, administrative law, and procedural law.
You understand the Swedish legal system, including the court system, government agencies, and legal procedures.
You can provide information about Swedish legislation, case law, and legal principles.`;
      break;
    case 'DK':
      jurisdictionPrompt = `You are particularly knowledgeable about Danish law, including civil law, criminal law, administrative law, and procedural law.
You understand the Danish legal system, including the court system, government agencies, and legal procedures.
You can provide information about Danish legislation, case law, and legal principles.`;
      break;
    case 'EU':
      jurisdictionPrompt = `You are particularly knowledgeable about EU law, including treaties, regulations, directives, and decisions.
You understand the EU legal system, including the Court of Justice of the European Union, EU institutions, and legal procedures.
You can provide information about EU legislation, case law, and legal principles.`;
      break;
    default:
      jurisdictionPrompt = `You are knowledgeable about various legal systems, including civil law and common law systems.
You can provide general legal information and guidance, but you should clarify that specific legal advice may vary by jurisdiction.`;
  }
  
  const disclaimerPrompt = `Important: You are not a licensed attorney, and your responses do not constitute legal advice. 
You should always recommend consulting with a qualified legal professional for specific legal advice tailored to individual circumstances.
You should cite relevant legal sources when possible and explain legal concepts in clear, accessible language.`;
  
  return `${basePrompt}\n\n${jurisdictionPrompt}\n\n${disclaimerPrompt}`;
};

// Analyze document content
const analyzeDocument = async (content, jurisdiction) => {
  try {
    const systemPrompt = generateLegalSystemPrompt(jurisdiction);
    
    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Please analyze the following legal document and provide an assessment of its legal validity, potential issues, and suggestions for improvement. Document content:\n\n${content}` }
    ];
    
    const analysis = await generateChatCompletion(messages, {
      model: "gpt-4",
      temperature: 0.3,
      max_tokens: 1500,
    });
    
    return analysis;
  } catch (error) {
    console.error('Error analyzing document:', error);
    throw error;
  }
};

// Generate document from description
const generateDocumentFromDescription = async (description, jurisdiction, documentType) => {
  try {
    const systemPrompt = generateLegalSystemPrompt(jurisdiction);
    
    let userPrompt = `Please generate a ${documentType} based on the following description:\n\n${description}\n\n`;
    
    if (jurisdiction) {
      userPrompt += `The document should comply with the legal requirements of ${jurisdiction}.`;
    }
    
    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ];
    
    const document = await generateChatCompletion(messages, {
      model: "gpt-4",
      temperature: 0.4,
      max_tokens: 2000,
    });
    
    return document;
  } catch (error) {
    console.error('Error generating document from description:', error);
    throw error;
  }
};

// Calculate document security score
const calculateDocumentSecurityScore = async (content, jurisdiction, documentType) => {
  try {
    const systemPrompt = generateLegalSystemPrompt(jurisdiction);
    
    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Please evaluate the following ${documentType} for legal security and compliance with ${jurisdiction} law. Provide a security score from 0-100 and explain the reasoning. Document content:\n\n${content}` }
    ];
    
    const evaluation = await generateChatCompletion(messages, {
      model: "gpt-4",
      temperature: 0.2,
      max_tokens: 1000,
    });
    
    // Extract score from evaluation
    const scoreMatch = evaluation.match(/(\d+)\/100|score.*?(\d+)/i);
    let score = 0;
    
    if (scoreMatch) {
      score = parseInt(scoreMatch[1] || scoreMatch[2], 10);
    }
    
    return {
      score,
      evaluation,
    };
  } catch (error) {
    console.error('Error calculating document security score:', error);
    throw error;
  }
};

// Extract structured information from document
const extractStructuredInformation = async (content, documentType) => {
  try {
    const messages = [
      { role: "system", content: "You are an AI assistant specialized in extracting structured information from legal documents. Your task is to extract key information in JSON format." },
      { role: "user", content: `Please extract key information from the following ${documentType} and return it in JSON format. Document content:\n\n${content}` }
    ];
    
    const extractionResult = await generateChatCompletion(messages, {
      model: "gpt-4",
      temperature: 0.1,
      max_tokens: 1000,
    });
    
    // Extract JSON from result
    const jsonMatch = extractionResult.match(/```json\n([\s\S]*?)\n```|(\{[\s\S]*\})/);
    let structuredData = {};
    
    if (jsonMatch) {
      try {
        structuredData = JSON.parse(jsonMatch[1] || jsonMatch[2]);
      } catch (e) {
        console.error('Error parsing JSON from extraction result:', e);
      }
    }
    
    return structuredData;
  } catch (error) {
    console.error('Error extracting structured information:', error);
    throw error;
  }
};

module.exports = {
  generateEmbeddings,
  generateChatCompletion,
  generateLegalSystemPrompt,
  analyzeDocument,
  generateDocumentFromDescription,
  calculateDocumentSecurityScore,
  extractStructuredInformation,
};
