const supabase = require('../utils/supabase');
const aiService = require('./aiService');
const lovdataService = require('./lovdataService');
const legalSourcesService = require('./legalSourcesService');

// Create vector store for document
const createVectorStore = async (document, userId) => {
  try {
    const embedding = await aiService.generateEmbeddings(document.content);
    
    // Store embedding in Supabase
    const { data, error } = await supabase
      .from('document_embeddings')
      .insert([
        {
          document_id: document.id,
          user_id: userId,
          embedding,
          content: document.content,
          metadata: {
            title: document.title,
            type: document.type,
            jurisdiction: document.jurisdiction,
          },
        }
      ]);
      
    if (error) {
      throw error;
    }
    
    return data;
  } catch (error) {
    console.error('Error creating vector store:', error);
    throw error;
  }
};

// Create vector store for law document
const createLawVectorStore = async (law, jurisdiction) => {
  try {
    const embedding = await aiService.generateEmbeddings(law.content);
    
    // Store embedding in Supabase
    const { data, error } = await supabase
      .from('law_embeddings')
      .insert([
        {
          law_id: law.id,
          jurisdiction,
          embedding,
          content: law.content,
          metadata: {
            title: law.title,
            type: law.type,
            section: law.section,
            year: law.year,
          },
        }
      ]);
      
    if (error) {
      throw error;
    }
    
    return data;
  } catch (error) {
    console.error('Error creating law vector store:', error);
    throw error;
  }
};

// Search vector store for similar documents
const searchVectorStore = async (query, userId, options = {}) => {
  try {
    const embedding = await aiService.generateEmbeddings(query);
    const matchThreshold = options.matchThreshold || 0.7;
    const limit = options.limit || 5;
    
    // Search for similar documents in Supabase
    const { data, error } = await supabase.rpc('match_documents', {
      query_embedding: embedding,
      match_threshold: matchThreshold,
      match_count: limit,
      p_user_id: userId,
    });
    
    if (error) {
      throw error;
    }
    
    return data || [];
  } catch (error) {
    console.error('Error searching vector store:', error);
    throw error;
  }
};

// Search vector store for similar laws
const searchLawVectorStore = async (query, jurisdiction, options = {}) => {
  try {
    const embedding = await aiService.generateEmbeddings(query);
    const matchThreshold = options.matchThreshold || 0.7;
    const limit = options.limit || 10;
    
    // Search for similar laws in Supabase
    const { data, error } = await supabase.rpc('match_laws', {
      query_embedding: embedding,
      match_threshold: matchThreshold,
      match_count: limit,
      p_jurisdiction: jurisdiction,
    });
    
    if (error) {
      throw error;
    }
    
    return data || [];
  } catch (error) {
    console.error('Error searching law vector store:', error);
    throw error;
  }
};

// Generate answer with RAG
const generateAnswerWithRAG = async (question, userId, jurisdiction) => {
  try {
    // Search for relevant documents
    const relevantDocuments = await searchVectorStore(question, userId, { limit: 3 });
    
    // Search for relevant laws
    const relevantLaws = await searchLawVectorStore(question, jurisdiction, { limit: 5 });
    
    // Combine relevant context
    let context = '';
    
    if (relevantDocuments.length > 0) {
      context += 'Relevant documents:\n\n';
      relevantDocuments.forEach((doc, index) => {
        context += `Document ${index + 1}: ${doc.metadata.title}\n${doc.content}\n\n`;
      });
    }
    
    if (relevantLaws.length > 0) {
      context += 'Relevant laws:\n\n';
      relevantLaws.forEach((law, index) => {
        context += `Law ${index + 1}: ${law.metadata.title}\n${law.content}\n\n`;
      });
    }
    
    // If no relevant context found, try to fetch from legal sources
    if (relevantDocuments.length === 0 && relevantLaws.length === 0) {
      try {
        let legalSourceResults;
        
        switch (jurisdiction) {
          case 'NO':
            legalSourceResults = await lovdataService.searchLaws(question);
            break;
          case 'SE':
            legalSourceResults = await legalSourcesService.searchSwedishLaws(question);
            break;
          case 'DK':
            legalSourceResults = await legalSourcesService.searchDanishLaws(question);
            break;
          case 'EU':
            legalSourceResults = await legalSourcesService.searchEULaws(question);
            break;
          default:
            legalSourceResults = await lovdataService.searchLaws(question);
        }
        
        if (legalSourceResults && legalSourceResults.length > 0) {
          context += 'Relevant legal sources:\n\n';
          legalSourceResults.slice(0, 3).forEach((source, index) => {
            context += `Source ${index + 1}: ${source.title}\n${source.content || source.excerpt}\n\n`;
          });
        }
      } catch (error) {
        console.error('Error fetching from legal sources:', error);
        // Continue without legal sources if there's an error
      }
    }
    
    // Generate system prompt
    const systemPrompt = aiService.generateLegalSystemPrompt(jurisdiction);
    
    // Generate answer
    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: `I need legal information about the following question: ${question}` }
    ];
    
    if (context) {
      messages.push({ role: "user", content: `Here is some relevant context that might help you answer the question:\n\n${context}` });
    }
    
    messages.push({ role: "user", content: `Based on the context provided and your knowledge, please answer the question: ${question}` });
    
    const answer = await aiService.generateChatCompletion(messages, {
      model: "gpt-4",
      temperature: 0.5,
      max_tokens: 1500,
    });
    
    return {
      answer,
      sources: {
        documents: relevantDocuments.map(doc => ({
          id: doc.document_id,
          title: doc.metadata.title,
          similarity: doc.similarity,
        })),
        laws: relevantLaws.map(law => ({
          id: law.law_id,
          title: law.metadata.title,
          similarity: law.similarity,
        })),
      },
    };
  } catch (error) {
    console.error('Error generating answer with RAG:', error);
    throw error;
  }
};

// Index law document
const indexLawDocument = async (law, jurisdiction) => {
  try {
    // Check if law already exists in vector store
    const { data: existingLaw, error: existingError } = await supabase
      .from('law_embeddings')
      .select('id')
      .eq('law_id', law.id)
      .eq('jurisdiction', jurisdiction)
      .single();
      
    if (!existingError && existingLaw) {
      // Law already indexed
      return existingLaw;
    }
    
    // Create vector store for law
    return await createLawVectorStore(law, jurisdiction);
  } catch (error) {
    console.error('Error indexing law document:', error);
    throw error;
  }
};

// Batch index laws
const batchIndexLaws = async (laws, jurisdiction) => {
  try {
    const results = [];
    
    for (const law of laws) {
      try {
        const result = await indexLawDocument(law, jurisdiction);
        results.push(result);
      } catch (error) {
        console.error(`Error indexing law ${law.id}:`, error);
        // Continue with next law
      }
    }
    
    return results;
  } catch (error) {
    console.error('Error batch indexing laws:', error);
    throw error;
  }
};

// Get fallback laws from Supabase
const getFallbackLaws = async (jurisdiction, category, limit = 100) => {
  try {
    let query = supabase
      .from('fallback_laws')
      .select('*')
      .eq('jurisdiction', jurisdiction)
      .limit(limit);
      
    if (category) {
      query = query.eq('category', category);
    }
    
    const { data, error } = await query;
    
    if (error) {
      throw error;
    }
    
    return data || [];
  } catch (error) {
    console.error('Error getting fallback laws:', error);
    throw error;
  }
};

// Store fallback law
const storeFallbackLaw = async (law, jurisdiction) => {
  try {
    // Check if law already exists
    const { data: existingLaw, error: existingError } = await supabase
      .from('fallback_laws')
      .select('id')
      .eq('law_id', law.id)
      .eq('jurisdiction', jurisdiction)
      .single();
      
    if (!existingError && existingLaw) {
      // Update existing law
      const { data, error } = await supabase
        .from('fallback_laws')
        .update({
          title: law.title,
          content: law.content,
          category: law.category,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingLaw.id)
        .select();
        
      if (error) {
        throw error;
      }
      
      return data[0];
    }
    
    // Insert new law
    const { data, error } = await supabase
      .from('fallback_laws')
      .insert([
        {
          law_id: law.id,
          jurisdiction,
          title: law.title,
          content: law.content,
          category: law.category,
        }
      ])
      .select();
      
    if (error) {
      throw error;
    }
    
    // Index the law for vector search
    await indexLawDocument({
      id: law.id,
      title: law.title,
      content: law.content,
      type: 'fallback',
      section: law.category,
      year: new Date().getFullYear(),
    }, jurisdiction);
    
    return data[0];
  } catch (error) {
    console.error('Error storing fallback law:', error);
    throw error;
  }
};

module.exports = {
  createVectorStore,
  createLawVectorStore,
  searchVectorStore,
  searchLawVectorStore,
  generateAnswerWithRAG,
  indexLawDocument,
  batchIndexLaws,
  getFallbackLaws,
  storeFallbackLaw,
};
