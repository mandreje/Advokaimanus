require('dotenv').config();
const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const chatRoutes = require('./routes/chat');
const documentRoutes = require('./routes/document');
const lawSearchRoutes = require('./routes/lawSearch');
const caseRoutes = require('./routes/case');
const tokenRoutes = require('./routes/token');
const jurisdictionRoutes = require('./routes/jurisdiction');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/document', documentRoutes);
app.use('/api/law-search', lawSearchRoutes);
app.use('/api/case', caseRoutes);
app.use('/api/token', tokenRoutes);
app.use('/api/jurisdiction', jurisdictionRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'AdvoKAI API is running' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: true,
    message: err.message || 'An unexpected error occurred',
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`AdvoKAI backend server running on port ${PORT}`);
});

module.exports = app;
