const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');
const authController = require('../controllers/authController');

// Get all chat conversations for a user
router.get('/', authController.authenticateToken, chatController.getConversations);

// Get a specific chat conversation
router.get('/:id', authController.authenticateToken, chatController.getConversation);

// Create a new chat conversation
router.post('/', authController.authenticateToken, chatController.createConversation);

// Send a message in a conversation
router.post('/:id/messages', authController.authenticateToken, chatController.sendMessage);

// Upload a document to a conversation
router.post('/:id/documents', authController.authenticateToken, chatController.uploadDocument);

// Delete a conversation
router.delete('/:id', authController.authenticateToken, chatController.deleteConversation);

module.exports = router;
