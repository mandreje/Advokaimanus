const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Register a new user
router.post('/register', authController.register);

// Login user
router.post('/login', authController.login);

// Forgot password
router.post('/forgot-password', authController.forgotPassword);

// Reset password
router.post('/reset-password', authController.resetPassword);

// Get current user
router.get('/user', authController.authenticateToken, authController.getCurrentUser);

// Update user profile
router.put('/profile', authController.authenticateToken, authController.updateProfile);

// Logout user
router.post('/logout', authController.authenticateToken, authController.logout);

module.exports = router;
