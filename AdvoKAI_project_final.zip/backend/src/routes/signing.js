const express = require('express');
const router = express.Router();
const signingController = require('../controllers/signingController');
const authMiddleware = require('../middleware/authMiddleware');

// Generate signature request
router.post('/request', authMiddleware, signingController.generateSignatureRequest);

// Get signature request
router.get('/request/:id', authMiddleware, signingController.getSignatureRequest);

// Verify signature token
router.get('/verify/:token', signingController.verifySignatureToken);

// Generate BankID authentication URL
router.post('/bankid/auth', signingController.generateBankIDAuthUrl);

// Process BankID callback
router.get('/bankid/callback', signingController.processBankIDCallback);

// Send signature request emails
router.post('/request/:id/send', authMiddleware, signingController.sendSignatureRequestEmails);

// Cancel signature request
router.post('/request/:id/cancel', authMiddleware, signingController.cancelSignatureRequest);

// Get signed document with proof
router.get('/document/:id/proof', authMiddleware, signingController.getSignedDocumentWithProof);

module.exports = router;
