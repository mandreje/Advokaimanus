const express = require('express');
const router = express.Router();
const jurisdictionController = require('../controllers/jurisdictionController');
const authController = require('../controllers/authController');

// Get available jurisdictions
router.get('/', authController.authenticateToken, jurisdictionController.getJurisdictions);

// Get user's current jurisdiction
router.get('/current', authController.authenticateToken, jurisdictionController.getCurrentJurisdiction);

// Set user's jurisdiction
router.post('/set', authController.authenticateToken, jurisdictionController.setJurisdiction);

// Get jurisdiction-specific settings
router.get('/:code/settings', authController.authenticateToken, jurisdictionController.getJurisdictionSettings);

module.exports = router;
