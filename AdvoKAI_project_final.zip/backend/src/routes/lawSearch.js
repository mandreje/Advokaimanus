const express = require('express');
const router = express.Router();
const lawSearchController = require('../controllers/lawSearchController');
const authController = require('../controllers/authController');

// Search laws and regulations
router.get('/search', authController.authenticateToken, lawSearchController.searchLaws);

// Get law details
router.get('/law/:id', authController.authenticateToken, lawSearchController.getLawDetails);

// Get recent searches
router.get('/recent', authController.authenticateToken, lawSearchController.getRecentSearches);

// Get popular laws by jurisdiction
router.get('/popular', authController.authenticateToken, lawSearchController.getPopularLaws);

// Save search
router.post('/save-search', authController.authenticateToken, lawSearchController.saveSearch);

module.exports = router;
