const express = require('express');
const router = express.Router();
const caseController = require('../controllers/caseController');
const authController = require('../controllers/authController');

// Get all cases for a user
router.get('/', authController.authenticateToken, caseController.getCases);

// Get a specific case
router.get('/:id', authController.authenticateToken, caseController.getCase);

// Create a new case
router.post('/', authController.authenticateToken, caseController.createCase);

// Update a case
router.put('/:id', authController.authenticateToken, caseController.updateCase);

// Delete a case
router.delete('/:id', authController.authenticateToken, caseController.deleteCase);

// Add document to case
router.post('/:id/documents', authController.authenticateToken, caseController.addDocumentToCase);

// Remove document from case
router.delete('/:id/documents/:documentId', authController.authenticateToken, caseController.removeDocumentFromCase);

// Add note to case
router.post('/:id/notes', authController.authenticateToken, caseController.addNoteToCase);

// Update case deadline
router.put('/:id/deadline', authController.authenticateToken, caseController.updateCaseDeadline);

// Update case status
router.put('/:id/status', authController.authenticateToken, caseController.updateCaseStatus);

module.exports = router;
