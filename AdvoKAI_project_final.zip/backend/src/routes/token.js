const express = require('express');
const router = express.Router();
const tokenController = require('../controllers/tokenController');
const authController = require('../controllers/authController');

// Get user token balance
router.get('/balance', authController.authenticateToken, tokenController.getTokenBalance);

// Get token transaction history
router.get('/transactions', authController.authenticateToken, tokenController.getTransactions);

// Purchase tokens
router.post('/purchase', authController.authenticateToken, tokenController.purchaseTokens);

// Apply promo code
router.post('/promo', authController.authenticateToken, tokenController.applyPromoCode);

// Get subscription plans
router.get('/plans', authController.authenticateToken, tokenController.getSubscriptionPlans);

// Subscribe to plan
router.post('/subscribe', authController.authenticateToken, tokenController.subscribeToPlan);

// Cancel subscription
router.post('/cancel-subscription', authController.authenticateToken, tokenController.cancelSubscription);

module.exports = router;
