const express = require('express');
const router = express.Router();
const documentController = require('../controllers/documentController');
const authController = require('../controllers/authController');

// Get all documents for a user
router.get('/', authController.authenticateToken, documentController.getDocuments);

// Get a specific document
router.get('/:id', authController.authenticateToken, documentController.getDocument);

// Get document templates
router.get('/templates/list', authController.authenticateToken, documentController.getTemplates);

// Create a document from template
router.post('/from-template', authController.authenticateToken, documentController.createFromTemplate);

// Create a document from description
router.post('/from-description', authController.authenticateToken, documentController.createFromDescription);

// Upload a document for analysis
router.post('/analyze', authController.authenticateToken, documentController.analyzeDocument);

// Update a document
router.put('/:id', authController.authenticateToken, documentController.updateDocument);

// Delete a document
router.delete('/:id', authController.authenticateToken, documentController.deleteDocument);

// Create a signature request
router.post('/:id/sign', authController.authenticateToken, documentController.createSignatureRequest);

// Check signature status
router.get('/:id/signature-status', authController.authenticateToken, documentController.checkSignatureStatus);

module.exports = router;
