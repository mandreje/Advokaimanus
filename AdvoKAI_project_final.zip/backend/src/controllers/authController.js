const supabase = require('../utils/supabase');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'advokai-secret-key';

// Middleware to authenticate JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: true, message: 'Access token required' });
  }
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: true, message: 'Invalid or expired token' });
    }
    
    req.user = user;
    next();
  });
};

// Register a new user
const register = async (req, res) => {
  try {
    const { email, password, first_name, last_name } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: true, message: 'Email and password are required' });
    }
    
    // Register user with Supabase
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });
    
    if (authError) {
      throw authError;
    }
    
    if (authData.user) {
      // Create profile record
      const { error: profileError } = await supabase
        .from('profiles')
        .insert([
          {
            id: authData.user.id,
            first_name: first_name || '',
            last_name: last_name || '',
            email,
            tokens: 100, // Give new users 100 free tokens
            preferred_jurisdiction: 'NO', // Default to Norway
          }
        ]);
        
      if (profileError) {
        throw profileError;
      }
      
      // Create token for frontend
      const token = jwt.sign({ id: authData.user.id, email: authData.user.email }, JWT_SECRET, { expiresIn: '7d' });
      
      return res.status(201).json({
        success: true,
        message: 'User registered successfully',
        user: {
          id: authData.user.id,
          email: authData.user.email,
        },
        token,
      });
    } else {
      return res.status(400).json({
        error: true,
        message: 'Registration failed',
      });
    }
  } catch (error) {
    console.error('Registration error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred during registration',
    });
  }
};

// Login user
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: true, message: 'Email and password are required' });
    }
    
    // Login with Supabase
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    if (authError) {
      throw authError;
    }
    
    if (authData.user) {
      // Get user profile
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authData.user.id)
        .single();
        
      if (profileError && profileError.code !== 'PGRST116') {
        throw profileError;
      }
      
      // Create token for frontend
      const token = jwt.sign({ id: authData.user.id, email: authData.user.email }, JWT_SECRET, { expiresIn: '7d' });
      
      return res.status(200).json({
        success: true,
        message: 'Login successful',
        user: {
          id: authData.user.id,
          email: authData.user.email,
          profile: profileData || null,
        },
        token,
      });
    } else {
      return res.status(401).json({
        error: true,
        message: 'Invalid credentials',
      });
    }
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred during login',
    });
  }
};

// Forgot password
const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: true, message: 'Email is required' });
    }
    
    // Send password reset email with Supabase
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: process.env.PASSWORD_RESET_REDIRECT_URL,
    });
    
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      message: 'Password reset email sent',
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while sending password reset email',
    });
  }
};

// Reset password
const resetPassword = async (req, res) => {
  try {
    const { password } = req.body;
    
    if (!password) {
      return res.status(400).json({ error: true, message: 'New password is required' });
    }
    
    // Update password with Supabase
    const { error } = await supabase.auth.updateUser({
      password,
    });
    
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      message: 'Password updated successfully',
    });
  } catch (error) {
    console.error('Reset password error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while resetting password',
    });
  }
};

// Get current user
const getCurrentUser = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get user data from Supabase
    const { data: userData, error: userError } = await supabase.auth.admin.getUserById(userId);
    
    if (userError) {
      throw userError;
    }
    
    if (!userData.user) {
      return res.status(404).json({
        error: true,
        message: 'User not found',
      });
    }
    
    // Get user profile
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
      
    if (profileError && profileError.code !== 'PGRST116') {
      throw profileError;
    }
    
    return res.status(200).json({
      success: true,
      user: {
        id: userData.user.id,
        email: userData.user.email,
        profile: profileData || null,
      },
    });
  } catch (error) {
    console.error('Get current user error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching user data',
    });
  }
};

// Update user profile
const updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const { first_name, last_name, phone, company, position, preferred_jurisdiction } = req.body;
    
    // Update profile in Supabase
    const { data, error } = await supabase
      .from('profiles')
      .update({
        first_name,
        last_name,
        phone,
        company,
        position,
        preferred_jurisdiction,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId)
      .select();
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      profile: data[0] || null,
    });
  } catch (error) {
    console.error('Update profile error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while updating profile',
    });
  }
};

// Logout user
const logout = async (req, res) => {
  try {
    // With JWT, we don't need to do anything on the server side
    // The client should remove the token
    
    return res.status(200).json({
      success: true,
      message: 'Logout successful',
    });
  } catch (error) {
    console.error('Logout error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred during logout',
    });
  }
};

module.exports = {
  authenticateToken,
  register,
  login,
  forgotPassword,
  resetPassword,
  getCurrentUser,
  updateProfile,
  logout,
};
