const supabase = require('../utils/supabase');

// Get user token balance
const getTokenBalance = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get user profile with token balance
    const { data, error } = await supabase
      .from('profiles')
      .select('tokens, subscription_status, subscription_expiry')
      .eq('id', userId)
      .single();
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      balance: data.tokens,
      subscription: {
        status: data.subscription_status,
        expiry: data.subscription_expiry,
      },
    });
  } catch (error) {
    console.error('Get token balance error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching token balance',
    });
  }
};

// Get token transaction history
const getTransactions = async (req, res) => {
  try {
    const userId = req.user.id;
    const { page = 1, limit = 20 } = req.query;
    
    // Get total count
    const { count, error: countError } = await supabase
      .from('token_transactions')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId);
      
    if (countError) {
      throw countError;
    }
    
    // Calculate pagination
    const offset = (page - 1) * limit;
    
    // Get transactions
    const { data, error } = await supabase
      .from('token_transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      transactions: data || [],
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: count,
        totalPages: Math.ceil(count / limit),
      },
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching transactions',
    });
  }
};

// Purchase tokens
const purchaseTokens = async (req, res) => {
  try {
    const userId = req.user.id;
    const { amount, payment_method, payment_details } = req.body;
    
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: true, message: 'Valid token amount is required' });
    }
    
    if (!payment_method) {
      return res.status(400).json({ error: true, message: 'Payment method is required' });
    }
    
    // In a real implementation, this would integrate with a payment processor
    // For now, we'll simulate a successful payment
    
    // Get current token balance
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    // Calculate price (in a real implementation, this would be based on pricing tiers)
    const price = amount * 0.1; // $0.10 per token
    
    // Update token balance
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ tokens: profile.tokens + amount })
      .eq('id', userId);
      
    if (updateError) {
      throw updateError;
    }
    
    // Record transaction
    const { data: transaction, error: transactionError } = await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount,
          transaction_type: 'purchase',
          description: `Purchased ${amount} tokens`,
          payment_method,
          payment_amount: price,
          payment_currency: 'USD',
        }
      ])
      .select();
      
    if (transactionError) {
      throw transactionError;
    }
    
    return res.status(200).json({
      success: true,
      message: `Successfully purchased ${amount} tokens`,
      transaction: transaction[0],
      new_balance: profile.tokens + amount,
    });
  } catch (error) {
    console.error('Purchase tokens error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while purchasing tokens',
    });
  }
};

// Apply promo code
const applyPromoCode = async (req, res) => {
  try {
    const userId = req.user.id;
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({ error: true, message: 'Promo code is required' });
    }
    
    // Check if promo code exists and is valid
    const { data: promo, error: promoError } = await supabase
      .from('promo_codes')
      .select('*')
      .eq('code', code)
      .single();
      
    if (promoError) {
      return res.status(404).json({
        error: true,
        message: 'Invalid promo code',
      });
    }
    
    if (!promo) {
      return res.status(404).json({
        error: true,
        message: 'Promo code not found',
      });
    }
    
    if (promo.is_used) {
      return res.status(400).json({
        error: true,
        message: 'Promo code has already been used',
      });
    }
    
    if (promo.expiry && new Date(promo.expiry) < new Date()) {
      return res.status(400).json({
        error: true,
        message: 'Promo code has expired',
      });
    }
    
    // Get current token balance
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    // Update token balance
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ tokens: profile.tokens + promo.token_amount })
      .eq('id', userId);
      
    if (updateError) {
      throw updateError;
    }
    
    // Mark promo code as used
    await supabase
      .from('promo_codes')
      .update({ is_used: true, used_by: userId, used_at: new Date().toISOString() })
      .eq('id', promo.id);
    
    // Record transaction
    const { data: transaction, error: transactionError } = await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: promo.token_amount,
          transaction_type: 'promo',
          description: `Applied promo code: ${code}`,
          reference_id: promo.id,
        }
      ])
      .select();
      
    if (transactionError) {
      throw transactionError;
    }
    
    return res.status(200).json({
      success: true,
      message: `Successfully applied promo code for ${promo.token_amount} tokens`,
      transaction: transaction[0],
      new_balance: profile.tokens + promo.token_amount,
    });
  } catch (error) {
    console.error('Apply promo code error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while applying promo code',
    });
  }
};

// Get subscription plans
const getSubscriptionPlans = async (req, res) => {
  try {
    // Get subscription plans from Supabase
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .order('price', { ascending: true });
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      plans: data || [],
    });
  } catch (error) {
    console.error('Get subscription plans error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching subscription plans',
    });
  }
};

// Subscribe to plan
const subscribeToPlan = async (req, res) => {
  try {
    const userId = req.user.id;
    const { plan_id, payment_method, payment_details } = req.body;
    
    if (!plan_id) {
      return res.status(400).json({ error: true, message: 'Plan ID is required' });
    }
    
    if (!payment_method) {
      return res.status(400).json({ error: true, message: 'Payment method is required' });
    }
    
    // Get plan details
    const { data: plan, error: planError } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('id', plan_id)
      .single();
      
    if (planError || !plan) {
      return res.status(404).json({
        error: true,
        message: 'Subscription plan not found',
      });
    }
    
    // In a real implementation, this would integrate with a payment processor
    // For now, we'll simulate a successful payment
    
    // Calculate expiry date
    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + 1); // 1 month subscription
    
    // Update user profile with subscription
    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        subscription_status: 'active',
        subscription_plan_id: plan_id,
        subscription_expiry: expiryDate.toISOString(),
        tokens: supabase.rpc('add_tokens', { amount: plan.monthly_tokens }),
      })
      .eq('id', userId);
      
    if (updateError) {
      throw updateError;
    }
    
    // Record subscription transaction
    const { data: transaction, error: transactionError } = await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: plan.monthly_tokens,
          transaction_type: 'subscription',
          description: `Subscribed to ${plan.name} plan`,
          payment_method,
          payment_amount: plan.price,
          payment_currency: 'USD',
          reference_id: plan_id,
        }
      ])
      .select();
      
    if (transactionError) {
      throw transactionError;
    }
    
    return res.status(200).json({
      success: true,
      message: `Successfully subscribed to ${plan.name} plan`,
      subscription: {
        plan: plan.name,
        monthly_tokens: plan.monthly_tokens,
        expiry: expiryDate.toISOString(),
      },
      transaction: transaction[0],
    });
  } catch (error) {
    console.error('Subscribe to plan error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while subscribing to plan',
    });
  }
};

// Cancel subscription
const cancelSubscription = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get user profile
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('subscription_status, subscription_plan_id')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (profile.subscription_status !== 'active') {
      return res.status(400).json({
        error: true,
        message: 'No active subscription to cancel',
      });
    }
    
    // Update user profile
    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        subscription_status: 'cancelled',
        // Note: We don't change the expiry date, so user can still use the subscription until it expires
      })
      .eq('id', userId);
      
    if (updateError) {
      throw updateError;
    }
    
    // Record cancellation
    await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: 0,
          transaction_type: 'subscription_cancel',
          description: 'Subscription cancelled',
          reference_id: profile.subscription_plan_id,
        }
      ]);
    
    return res.status(200).json({
      success: true,
      message: 'Subscription cancelled successfully',
    });
  } catch (error) {
    console.error('Cancel subscription error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while cancelling subscription',
    });
  }
};

module.exports = {
  getTokenBalance,
  getTransactions,
  purchaseTokens,
  applyPromoCode,
  getSubscriptionPlans,
  subscribeToPlan,
  cancelSubscription,
};
