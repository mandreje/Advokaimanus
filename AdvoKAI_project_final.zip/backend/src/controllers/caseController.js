const supabase = require('../utils/supabase');
const { v4: uuidv4 } = require('uuid');

// Get all cases for a user
const getCases = async (req, res) => {
  try {
    const userId = req.user.id;
    const { status } = req.query;
    
    // Get cases from Supabase
    let query = supabase
      .from('cases')
      .select('*, case_documents(document_id)')
      .eq('user_id', userId);
      
    if (status) {
      query = query.eq('status', status);
    }
    
    const { data, error } = await query.order('updated_at', { ascending: false });
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      cases: data || [],
    });
  } catch (error) {
    console.error('Get cases error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching cases',
    });
  }
};

// Get a specific case
const getCase = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    
    // Get case from Supabase
    const { data: caseData, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError) {
      throw caseError;
    }
    
    if (!caseData) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Get case documents
    const { data: documents, error: documentsError } = await supabase
      .from('case_documents')
      .select('documents(*)')
      .eq('case_id', caseId);
      
    if (documentsError) {
      throw documentsError;
    }
    
    // Get case notes
    const { data: notes, error: notesError } = await supabase
      .from('case_notes')
      .select('*')
      .eq('case_id', caseId)
      .order('created_at', { ascending: false });
      
    if (notesError) {
      throw notesError;
    }
    
    return res.status(200).json({
      success: true,
      case: {
        ...caseData,
        documents: documents ? documents.map(doc => doc.documents) : [],
        notes: notes || [],
      },
    });
  } catch (error) {
    console.error('Get case error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching case',
    });
  }
};

// Create a new case
const createCase = async (req, res) => {
  try {
    const userId = req.user.id;
    const { title, description, type, jurisdiction, deadline } = req.body;
    
    if (!title) {
      return res.status(400).json({ error: true, message: 'Title is required' });
    }
    
    // Create case in Supabase
    const { data, error } = await supabase
      .from('cases')
      .insert([
        {
          user_id: userId,
          title,
          description: description || '',
          type: type || 'general',
          jurisdiction: jurisdiction || 'NO',
          status: 'open',
          deadline: deadline || null,
        }
      ])
      .select();
      
    if (error) {
      throw error;
    }
    
    return res.status(201).json({
      success: true,
      message: 'Case created successfully',
      case: data[0],
    });
  } catch (error) {
    console.error('Create case error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while creating case',
    });
  }
};

// Update a case
const updateCase = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    const { title, description, type, jurisdiction, status, deadline } = req.body;
    
    // Check if case exists and belongs to user
    const { data: existingCase, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError || !existingCase) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Update case in Supabase
    const { data, error } = await supabase
      .from('cases')
      .update({
        title: title || existingCase.title,
        description: description !== undefined ? description : existingCase.description,
        type: type || existingCase.type,
        jurisdiction: jurisdiction || existingCase.jurisdiction,
        status: status || existingCase.status,
        deadline: deadline !== undefined ? deadline : existingCase.deadline,
        updated_at: new Date().toISOString(),
      })
      .eq('id', caseId)
      .select();
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      message: 'Case updated successfully',
      case: data[0],
    });
  } catch (error) {
    console.error('Update case error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while updating case',
    });
  }
};

// Delete a case
const deleteCase = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    
    // Check if case exists and belongs to user
    const { data: existingCase, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError || !existingCase) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Delete case notes
    await supabase
      .from('case_notes')
      .delete()
      .eq('case_id', caseId);
    
    // Delete case document associations (but not the documents themselves)
    await supabase
      .from('case_documents')
      .delete()
      .eq('case_id', caseId);
    
    // Delete case
    await supabase
      .from('cases')
      .delete()
      .eq('id', caseId);
    
    return res.status(200).json({
      success: true,
      message: 'Case deleted successfully',
    });
  } catch (error) {
    console.error('Delete case error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while deleting case',
    });
  }
};

// Add document to case
const addDocumentToCase = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    const { document_id } = req.body;
    
    if (!document_id) {
      return res.status(400).json({ error: true, message: 'Document ID is required' });
    }
    
    // Check if case exists and belongs to user
    const { data: existingCase, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError || !existingCase) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Check if document exists and belongs to user
    const { data: existingDocument, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', document_id)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !existingDocument) {
      return res.status(404).json({
        error: true,
        message: 'Document not found',
      });
    }
    
    // Check if document is already associated with the case
    const { data: existingAssociation, error: associationError } = await supabase
      .from('case_documents')
      .select('*')
      .eq('case_id', caseId)
      .eq('document_id', document_id)
      .single();
      
    if (existingAssociation) {
      return res.status(400).json({
        error: true,
        message: 'Document is already associated with this case',
      });
    }
    
    // Add document to case
    const { data, error } = await supabase
      .from('case_documents')
      .insert([
        {
          case_id: caseId,
          document_id,
        }
      ])
      .select();
      
    if (error) {
      throw error;
    }
    
    // Update case timestamp
    await supabase
      .from('cases')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', caseId);
    
    return res.status(201).json({
      success: true,
      message: 'Document added to case successfully',
      association: data[0],
    });
  } catch (error) {
    console.error('Add document to case error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while adding document to case',
    });
  }
};

// Remove document from case
const removeDocumentFromCase = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    const documentId = req.params.documentId;
    
    // Check if case exists and belongs to user
    const { data: existingCase, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError || !existingCase) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Remove document from case
    await supabase
      .from('case_documents')
      .delete()
      .eq('case_id', caseId)
      .eq('document_id', documentId);
    
    // Update case timestamp
    await supabase
      .from('cases')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', caseId);
    
    return res.status(200).json({
      success: true,
      message: 'Document removed from case successfully',
    });
  } catch (error) {
    console.error('Remove document from case error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while removing document from case',
    });
  }
};

// Add note to case
const addNoteToCase = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    const { content } = req.body;
    
    if (!content) {
      return res.status(400).json({ error: true, message: 'Note content is required' });
    }
    
    // Check if case exists and belongs to user
    const { data: existingCase, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError || !existingCase) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Add note to case
    const { data, error } = await supabase
      .from('case_notes')
      .insert([
        {
          case_id: caseId,
          content,
          created_by: userId,
        }
      ])
      .select();
      
    if (error) {
      throw error;
    }
    
    // Update case timestamp
    await supabase
      .from('cases')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', caseId);
    
    return res.status(201).json({
      success: true,
      message: 'Note added to case successfully',
      note: data[0],
    });
  } catch (error) {
    console.error('Add note to case error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while adding note to case',
    });
  }
};

// Update case deadline
const updateCaseDeadline = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    const { deadline } = req.body;
    
    // Check if case exists and belongs to user
    const { data: existingCase, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError || !existingCase) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Update case deadline
    const { data, error } = await supabase
      .from('cases')
      .update({
        deadline,
        updated_at: new Date().toISOString(),
      })
      .eq('id', caseId)
      .select();
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      message: 'Case deadline updated successfully',
      case: data[0],
    });
  } catch (error) {
    console.error('Update case deadline error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while updating case deadline',
    });
  }
};

// Update case status
const updateCaseStatus = async (req, res) => {
  try {
    const userId = req.user.id;
    const caseId = req.params.id;
    const { status } = req.body;
    
    if (!status) {
      return res.status(400).json({ error: true, message: 'Status is required' });
    }
    
    // Check if status is valid
    const validStatuses = ['open', 'in_progress', 'pending', 'closed', 'archived'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: true,
        message: 'Invalid status. Must be one of: ' + validStatuses.join(', '),
      });
    }
    
    // Check if case exists and belongs to user
    const { data: existingCase, error: caseError } = await supabase
      .from('cases')
      .select('*')
      .eq('id', caseId)
      .eq('user_id', userId)
      .single();
      
    if (caseError || !existingCase) {
      return res.status(404).json({
        error: true,
        message: 'Case not found',
      });
    }
    
    // Update case status
    const { data, error } = await supabase
      .from('cases')
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq('id', caseId)
      .select();
      
    if (error) {
      throw error;
    }
    
    // Add note about status change
    await supabase
      .from('case_notes')
      .insert([
        {
          case_id: caseId,
          content: `Case status changed to ${status}`,
          created_by: userId,
          is_system_note: true,
        }
      ]);
    
    return res.status(200).json({
      success: true,
      message: 'Case status updated successfully',
      case: data[0],
    });
  } catch (error) {
    console.error('Update case status error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while updating case status',
    });
  }
};

module.exports = {
  getCases,
  getCase,
  createCase,
  updateCase,
  deleteCase,
  addDocumentToCase,
  removeDocumentFromCase,
  addNoteToCase,
  updateCaseDeadline,
  updateCaseStatus,
};
