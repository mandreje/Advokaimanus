const supabase = require('../utils/supabase');
const openaiService = require('../services/openaiService');
const documentGeneratorService = require('../services/documentGeneratorService');
const criiptoService = require('../services/criiptoService');
const { v4: uuidv4 } = require('uuid');

// Get all documents for a user
const getDocuments = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get documents from Supabase
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      documents: data || [],
    });
  } catch (error) {
    console.error('Get documents error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching documents',
    });
  }
};

// Get a specific document
const getDocument = async (req, res) => {
  try {
    const userId = req.user.id;
    const documentId = req.params.id;
    
    // Get document from Supabase
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError) {
      throw documentError;
    }
    
    if (!document) {
      return res.status(404).json({
        error: true,
        message: 'Document not found',
      });
    }
    
    // Get document versions
    const { data: versions, error: versionsError } = await supabase
      .from('document_versions')
      .select('*')
      .eq('document_id', documentId)
      .order('created_at', { ascending: false });
      
    if (versionsError) {
      throw versionsError;
    }
    
    // Get document signatures
    const { data: signatures, error: signaturesError } = await supabase
      .from('document_signatures')
      .select('*')
      .eq('document_id', documentId)
      .order('created_at', { ascending: false });
      
    if (signaturesError) {
      throw signaturesError;
    }
    
    return res.status(200).json({
      success: true,
      document: {
        ...document,
        versions: versions || [],
        signatures: signatures || [],
      },
    });
  } catch (error) {
    console.error('Get document error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching document',
    });
  }
};

// Get document templates
const getTemplates = async (req, res) => {
  try {
    const { jurisdiction } = req.query;
    
    // Get templates from Supabase
    let query = supabase
      .from('document_templates')
      .select('*');
      
    if (jurisdiction) {
      query = query.eq('jurisdiction', jurisdiction);
    }
    
    const { data, error } = await query.order('name', { ascending: true });
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      templates: data || [],
    });
  } catch (error) {
    console.error('Get templates error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching templates',
    });
  }
};

// Create a document from template
const createFromTemplate = async (req, res) => {
  try {
    const userId = req.user.id;
    const { template_id, title, variables } = req.body;
    
    if (!template_id) {
      return res.status(400).json({ error: true, message: 'Template ID is required' });
    }
    
    // Check if user has enough tokens
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (profile.tokens < 5) {
      return res.status(403).json({
        error: true,
        message: 'Not enough tokens to create document',
      });
    }
    
    // Get template
    const { data: template, error: templateError } = await supabase
      .from('document_templates')
      .select('*')
      .eq('id', template_id)
      .single();
      
    if (templateError || !template) {
      return res.status(404).json({
        error: true,
        message: 'Template not found',
      });
    }
    
    // Generate document content
    const content = await documentGeneratorService.generateFromTemplate(template.content, variables);
    
    // Create document in Supabase
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .insert([
        {
          user_id: userId,
          title: title || template.name,
          type: 'template',
          template_id: template_id,
          jurisdiction: template.jurisdiction,
          status: 'draft',
          security_score: 90, // Default high score for template-based documents
        }
      ])
      .select();
      
    if (documentError) {
      throw documentError;
    }
    
    // Create initial version
    const { error: versionError } = await supabase
      .from('document_versions')
      .insert([
        {
          document_id: document[0].id,
          content,
          version_number: 1,
          created_by: userId,
        }
      ]);
      
    if (versionError) {
      throw versionError;
    }
    
    // Deduct tokens from user
    await supabase
      .from('profiles')
      .update({ tokens: profile.tokens - 5 })
      .eq('id', userId);
    
    // Record token usage
    await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: 5,
          transaction_type: 'usage',
          description: 'Document creation from template',
          reference_id: document[0].id,
        }
      ]);
    
    return res.status(201).json({
      success: true,
      message: 'Document created successfully',
      document: document[0],
    });
  } catch (error) {
    console.error('Create from template error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while creating document',
    });
  }
};

// Create a document from description
const createFromDescription = async (req, res) => {
  try {
    const userId = req.user.id;
    const { title, description, jurisdiction } = req.body;
    
    if (!description) {
      return res.status(400).json({ error: true, message: 'Description is required' });
    }
    
    // Check if user has enough tokens
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (profile.tokens < 10) {
      return res.status(403).json({
        error: true,
        message: 'Not enough tokens to create document from description',
      });
    }
    
    // Generate document content
    const content = await documentGeneratorService.generateFromDescription(description, jurisdiction || 'NO');
    
    // Create document in Supabase
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .insert([
        {
          user_id: userId,
          title: title || 'Document from description',
          type: 'description',
          jurisdiction: jurisdiction || 'NO',
          status: 'draft',
          security_score: 70, // Default medium score for description-based documents
        }
      ])
      .select();
      
    if (documentError) {
      throw documentError;
    }
    
    // Create initial version
    const { error: versionError } = await supabase
      .from('document_versions')
      .insert([
        {
          document_id: document[0].id,
          content,
          version_number: 1,
          created_by: userId,
        }
      ]);
      
    if (versionError) {
      throw versionError;
    }
    
    // Deduct tokens from user
    await supabase
      .from('profiles')
      .update({ tokens: profile.tokens - 10 })
      .eq('id', userId);
    
    // Record token usage
    await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: 10,
          transaction_type: 'usage',
          description: 'Document creation from description',
          reference_id: document[0].id,
        }
      ]);
    
    return res.status(201).json({
      success: true,
      message: 'Document created successfully',
      document: document[0],
    });
  } catch (error) {
    console.error('Create from description error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while creating document',
    });
  }
};

// Upload a document for analysis
const analyzeDocument = async (req, res) => {
  try {
    const userId = req.user.id;
    const { file } = req.files;
    const { jurisdiction } = req.body;
    
    if (!file) {
      return res.status(400).json({ error: true, message: 'File is required' });
    }
    
    // Check if user has enough tokens
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (profile.tokens < 8) {
      return res.status(403).json({
        error: true,
        message: 'Not enough tokens to analyze document',
      });
    }
    
    // Generate unique filename
    const fileExt = file.name.split('.').pop();
    const fileName = `${uuidv4()}.${fileExt}`;
    const filePath = `documents/${userId}/${fileName}`;
    
    // Upload file to Supabase Storage
    const { data: storageData, error: storageError } = await supabase
      .storage
      .from('documents')
      .upload(filePath, file.data, {
        contentType: file.mimetype,
      });
      
    if (storageError) {
      throw storageError;
    }
    
    // Get public URL
    const { data: urlData } = await supabase
      .storage
      .from('documents')
      .getPublicUrl(filePath);
    
    // Extract text from document
    const text = await documentGeneratorService.extractTextFromDocument(file.data, file.mimetype);
    
    // Analyze document
    const analysis = await documentGeneratorService.analyzeDocument(text, jurisdiction || 'NO');
    
    // Create document in Supabase
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .insert([
        {
          user_id: userId,
          title: file.name,
          type: 'upload',
          jurisdiction: jurisdiction || 'NO',
          status: 'analyzed',
          security_score: analysis.security_score,
          file_path: filePath,
          file_type: file.mimetype,
          file_size: file.size,
          public_url: urlData.publicUrl,
        }
      ])
      .select();
      
    if (documentError) {
      throw documentError;
    }
    
    // Create analysis record
    const { error: analysisError } = await supabase
      .from('document_analyses')
      .insert([
        {
          document_id: document[0].id,
          analysis_result: analysis,
        }
      ]);
      
    if (analysisError) {
      throw analysisError;
    }
    
    // Deduct tokens from user
    await supabase
      .from('profiles')
      .update({ tokens: profile.tokens - 8 })
      .eq('id', userId);
    
    // Record token usage
    await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: 8,
          transaction_type: 'usage',
          description: 'Document analysis',
          reference_id: document[0].id,
        }
      ]);
    
    return res.status(200).json({
      success: true,
      message: 'Document analyzed successfully',
      document: document[0],
      analysis,
    });
  } catch (error) {
    console.error('Analyze document error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while analyzing document',
    });
  }
};

// Update a document
const updateDocument = async (req, res) => {
  try {
    const userId = req.user.id;
    const documentId = req.params.id;
    const { title, content } = req.body;
    
    // Check if document exists and belongs to user
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !document) {
      return res.status(404).json({
        error: true,
        message: 'Document not found',
      });
    }
    
    // Update document title if provided
    if (title) {
      await supabase
        .from('documents')
        .update({ 
          title,
          updated_at: new Date().toISOString()
        })
        .eq('id', documentId);
    }
    
    // Create new version if content provided
    if (content) {
      // Get latest version number
      const { data: latestVersion, error: versionError } = await supabase
        .from('document_versions')
        .select('version_number')
        .eq('document_id', documentId)
        .order('version_number', { ascending: false })
        .limit(1)
        .single();
        
      if (versionError && versionError.code !== 'PGRST116') {
        throw versionError;
      }
      
      const newVersionNumber = latestVersion ? latestVersion.version_number + 1 : 1;
      
      // Create new version
      await supabase
        .from('document_versions')
        .insert([
          {
            document_id: documentId,
            content,
            version_number: newVersionNumber,
            created_by: userId,
          }
        ]);
        
      // Update document
      await supabase
        .from('documents')
        .update({ 
          updated_at: new Date().toISOString(),
          status: 'draft'
        })
        .eq('id', documentId);
    }
    
    return res.status(200).json({
      success: true,
      message: 'Document updated successfully',
    });
  } catch (error) {
    console.error('Update document error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while updating document',
    });
  }
};

// Delete a document
const deleteDocument = async (req, res) => {
  try {
    const userId = req.user.id;
    const documentId = req.params.id;
    
    // Check if document exists and belongs to user
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !document) {
      return res.status(404).json({
        error: true,
        message: 'Document not found',
      });
    }
    
    // Delete document versions
    await supabase
      .from('document_versions')
      .delete()
      .eq('document_id', documentId);
    
    // Delete document analyses
    await supabase
      .from('document_analyses')
      .delete()
      .eq('document_id', documentId);
    
    // Delete document signatures
    await supabase
      .from('document_signatures')
      .delete()
      .eq('document_id', documentId);
    
    // Delete document file if exists
    if (document.file_path) {
      await supabase
        .storage
        .from('documents')
        .remove([document.file_path]);
    }
    
    // Delete document
    await supabase
      .from('documents')
      .delete()
      .eq('id', documentId);
    
    return res.status(200).json({
      success: true,
      message: 'Document deleted successfully',
    });
  } catch (error) {
    console.error('Delete document error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while deleting document',
    });
  }
};

// Create a signature request
const createSignatureRequest = async (req, res) => {
  try {
    const userId = req.user.id;
    const documentId = req.params.id;
    const { signers, message } = req.body;
    
    if (!signers || !Array.isArray(signers) || signers.length === 0) {
      return res.status(400).json({ error: true, message: 'Signers are required' });
    }
    
    // Check if document exists and belongs to user
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !document) {
      return res.status(404).json({
        error: true,
        message: 'Document not found',
      });
    }
    
    // Check if user has enough tokens
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (profile.tokens < 5) {
      return res.status(403).json({
        error: true,
        message: 'Not enough tokens to create signature request',
      });
    }
    
    // Get latest document version
    const { data: latestVersion, error: versionError } = await supabase
      .from('document_versions')
      .select('*')
      .eq('document_id', documentId)
      .order('version_number', { ascending: false })
      .limit(1)
      .single();
      
    if (versionError) {
      throw versionError;
    }
    
    // Create signature request with Criipto
    const signatureRequest = await criiptoService.createSignatureRequest(
      document.title,
      latestVersion.content,
      signers,
      message || `Please sign this document: ${document.title}`
    );
    
    // Save signature request to database
    const { error: signatureError } = await supabase
      .from('document_signatures')
      .insert([
        {
          document_id: documentId,
          signature_request_id: signatureRequest.id,
          status: 'pending',
          signers: signers,
        }
      ]);
      
    if (signatureError) {
      throw signatureError;
    }
    
    // Update document status
    await supabase
      .from('documents')
      .update({ 
        status: 'signing',
        updated_at: new Date().toISOString()
      })
      .eq('id', documentId);
    
    // Deduct tokens from user
    await supabase
      .from('profiles')
      .update({ tokens: profile.tokens - 5 })
      .eq('id', userId);
    
    // Record token usage
    await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: 5,
          transaction_type: 'usage',
          description: 'Signature request',
          reference_id: documentId,
        }
      ]);
    
    return res.status(200).json({
      success: true,
      message: 'Signature request created successfully',
      signatureRequest,
    });
  } catch (error) {
    console.error('Create signature request error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while creating signature request',
    });
  }
};

// Check signature status
const checkSignatureStatus = async (req, res) => {
  try {
    const userId = req.user.id;
    const documentId = req.params.id;
    
    // Check if document exists and belongs to user
    const { data: document, error: documentError } = await supabase
      .from('documents')
      .select('*')
      .eq('id', documentId)
      .eq('user_id', userId)
      .single();
      
    if (documentError || !document) {
      return res.status(404).json({
        error: true,
        message: 'Document not found',
      });
    }
    
    // Get signature request
    const { data: signatureRequest, error: signatureError } = await supabase
      .from('document_signatures')
      .select('*')
      .eq('document_id', documentId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
      
    if (signatureError) {
      throw signatureError;
    }
    
    if (!signatureRequest) {
      return res.status(404).json({
        error: true,
        message: 'No signature request found for this document',
      });
    }
    
    // Check status with Criipto
    const status = await criiptoService.checkSignatureStatus(signatureRequest.signature_request_id);
    
    // Update status in database if changed
    if (status !== signatureRequest.status) {
      await supabase
        .from('document_signatures')
        .update({ status })
        .eq('id', signatureRequest.id);
        
      // Update document status if all signatures completed
      if (status === 'completed') {
        await supabase
          .from('documents')
          .update({ 
            status: 'signed',
            updated_at: new Date().toISOString()
          })
          .eq('id', documentId);
      }
    }
    
    return res.status(200).json({
      success: true,
      status,
    });
  } catch (error) {
    console.error('Check signature status error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while checking signature status',
    });
  }
};

module.exports = {
  getDocuments,
  getDocument,
  getTemplates,
  createFromTemplate,
  createFromDescription,
  analyzeDocument,
  updateDocument,
  deleteDocument,
  createSignatureRequest,
  checkSignatureStatus,
};
