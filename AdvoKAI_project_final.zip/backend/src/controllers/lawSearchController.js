const supabase = require('../utils/supabase');
const lovdataService = require('../services/lovdataService');
const legalSourcesService = require('../services/legalSourcesService');

// Search laws and regulations
const searchLaws = async (req, res) => {
  try {
    const userId = req.user.id;
    const { query, jurisdiction, category, page = 1, limit = 20 } = req.query;
    
    if (!query) {
      return res.status(400).json({ error: true, message: 'Search query is required' });
    }
    
    // Check if user has enough tokens
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (profile.tokens < 1) {
      return res.status(403).json({
        error: true,
        message: 'Not enough tokens to perform search',
      });
    }
    
    // Determine which service to use based on jurisdiction
    let searchResults;
    switch (jurisdiction) {
      case 'NO':
        searchResults = await lovdataService.searchLaws(query, category);
        break;
      case 'SE':
        searchResults = await legalSourcesService.searchSwedishLaws(query, category);
        break;
      case 'DK':
        searchResults = await legalSourcesService.searchDanishLaws(query, category);
        break;
      case 'EU':
        searchResults = await legalSourcesService.searchEULaws(query, category);
        break;
      default:
        // Default to Norwegian laws if no jurisdiction specified
        searchResults = await lovdataService.searchLaws(query, category);
    }
    
    // Calculate pagination
    const offset = (page - 1) * limit;
    const paginatedResults = searchResults.slice(offset, offset + limit);
    const totalPages = Math.ceil(searchResults.length / limit);
    
    // Save search to history
    await supabase
      .from('law_search_history')
      .insert([
        {
          user_id: userId,
          query,
          jurisdiction: jurisdiction || 'NO',
          category: category || null,
          result_count: searchResults.length,
        }
      ]);
    
    // Deduct tokens from user
    await supabase
      .from('profiles')
      .update({ tokens: profile.tokens - 1 })
      .eq('id', userId);
    
    // Record token usage
    await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: 1,
          transaction_type: 'usage',
          description: 'Law search',
          reference_id: null,
        }
      ]);
    
    return res.status(200).json({
      success: true,
      results: paginatedResults,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: searchResults.length,
        totalPages,
      },
    });
  } catch (error) {
    console.error('Search laws error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while searching laws',
    });
  }
};

// Get law details
const getLawDetails = async (req, res) => {
  try {
    const userId = req.user.id;
    const lawId = req.params.id;
    const { jurisdiction } = req.query;
    
    if (!lawId) {
      return res.status(400).json({ error: true, message: 'Law ID is required' });
    }
    
    // Determine which service to use based on jurisdiction
    let lawDetails;
    switch (jurisdiction) {
      case 'NO':
        lawDetails = await lovdataService.getLawDetails(lawId);
        break;
      case 'SE':
        lawDetails = await legalSourcesService.getSwedishLawDetails(lawId);
        break;
      case 'DK':
        lawDetails = await legalSourcesService.getDanishLawDetails(lawId);
        break;
      case 'EU':
        lawDetails = await legalSourcesService.getEULawDetails(lawId);
        break;
      default:
        // Default to Norwegian laws if no jurisdiction specified
        lawDetails = await lovdataService.getLawDetails(lawId);
    }
    
    if (!lawDetails) {
      return res.status(404).json({
        error: true,
        message: 'Law not found',
      });
    }
    
    // Record view in popular laws
    await supabase
      .from('popular_laws')
      .upsert([
        {
          law_id: lawId,
          jurisdiction: jurisdiction || 'NO',
          view_count: 1,
        }
      ], {
        onConflict: 'law_id, jurisdiction',
        ignoreDuplicates: false,
      });
    
    // Increment view count
    await supabase.rpc('increment_law_view_count', {
      p_law_id: lawId,
      p_jurisdiction: jurisdiction || 'NO',
    });
    
    return res.status(200).json({
      success: true,
      law: lawDetails,
    });
  } catch (error) {
    console.error('Get law details error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching law details',
    });
  }
};

// Get recent searches
const getRecentSearches = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get recent searches from Supabase
    const { data, error } = await supabase
      .from('law_search_history')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(10);
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      searches: data || [],
    });
  } catch (error) {
    console.error('Get recent searches error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching recent searches',
    });
  }
};

// Get popular laws by jurisdiction
const getPopularLaws = async (req, res) => {
  try {
    const { jurisdiction } = req.query;
    
    // Get popular laws from Supabase
    let query = supabase
      .from('popular_laws')
      .select('*')
      .order('view_count', { ascending: false })
      .limit(10);
      
    if (jurisdiction) {
      query = query.eq('jurisdiction', jurisdiction);
    }
    
    const { data, error } = await query;
      
    if (error) {
      throw error;
    }
    
    // Get law details for each popular law
    const popularLaws = [];
    for (const item of data) {
      let lawDetails;
      switch (item.jurisdiction) {
        case 'NO':
          lawDetails = await lovdataService.getLawDetails(item.law_id);
          break;
        case 'SE':
          lawDetails = await legalSourcesService.getSwedishLawDetails(item.law_id);
          break;
        case 'DK':
          lawDetails = await legalSourcesService.getDanishLawDetails(item.law_id);
          break;
        case 'EU':
          lawDetails = await legalSourcesService.getEULawDetails(item.law_id);
          break;
        default:
          lawDetails = await lovdataService.getLawDetails(item.law_id);
      }
      
      if (lawDetails) {
        popularLaws.push({
          ...lawDetails,
          view_count: item.view_count,
        });
      }
    }
    
    return res.status(200).json({
      success: true,
      laws: popularLaws,
    });
  } catch (error) {
    console.error('Get popular laws error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching popular laws',
    });
  }
};

// Save search
const saveSearch = async (req, res) => {
  try {
    const userId = req.user.id;
    const { query, jurisdiction, category, name } = req.body;
    
    if (!query || !name) {
      return res.status(400).json({ error: true, message: 'Query and name are required' });
    }
    
    // Save search to Supabase
    const { data, error } = await supabase
      .from('saved_searches')
      .insert([
        {
          user_id: userId,
          name,
          query,
          jurisdiction: jurisdiction || 'NO',
          category: category || null,
        }
      ])
      .select();
      
    if (error) {
      throw error;
    }
    
    return res.status(201).json({
      success: true,
      message: 'Search saved successfully',
      savedSearch: data[0],
    });
  } catch (error) {
    console.error('Save search error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while saving search',
    });
  }
};

module.exports = {
  searchLaws,
  getLawDetails,
  getRecentSearches,
  getPopularLaws,
  saveSearch,
};
