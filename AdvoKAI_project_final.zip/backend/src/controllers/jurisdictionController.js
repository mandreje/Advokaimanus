const supabase = require('../utils/supabase');

// Get available jurisdictions
const getJurisdictions = async (req, res) => {
  try {
    // Get jurisdictions from Supabase
    const { data, error } = await supabase
      .from('jurisdictions')
      .select('*')
      .order('name', { ascending: true });
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      jurisdictions: data || [],
    });
  } catch (error) {
    console.error('Get jurisdictions error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching jurisdictions',
    });
  }
};

// Get user's current jurisdiction
const getCurrentJurisdiction = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get user profile with jurisdiction
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('jurisdiction')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (!profile.jurisdiction) {
      return res.status(200).json({
        success: true,
        jurisdiction: 'NO', // Default to Norway
      });
    }
    
    // Get jurisdiction details
    const { data: jurisdiction, error: jurisdictionError } = await supabase
      .from('jurisdictions')
      .select('*')
      .eq('code', profile.jurisdiction)
      .single();
      
    if (jurisdictionError) {
      throw jurisdictionError;
    }
    
    return res.status(200).json({
      success: true,
      jurisdiction: jurisdiction || { code: 'NO', name: 'Norway' }, // Default if not found
    });
  } catch (error) {
    console.error('Get current jurisdiction error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching current jurisdiction',
    });
  }
};

// Set user's jurisdiction
const setJurisdiction = async (req, res) => {
  try {
    const userId = req.user.id;
    const { jurisdiction } = req.body;
    
    if (!jurisdiction) {
      return res.status(400).json({ error: true, message: 'Jurisdiction code is required' });
    }
    
    // Check if jurisdiction exists
    const { data: jurisdictionData, error: jurisdictionError } = await supabase
      .from('jurisdictions')
      .select('*')
      .eq('code', jurisdiction)
      .single();
      
    if (jurisdictionError || !jurisdictionData) {
      return res.status(404).json({
        error: true,
        message: 'Jurisdiction not found',
      });
    }
    
    // Update user profile
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ jurisdiction })
      .eq('id', userId);
      
    if (updateError) {
      throw updateError;
    }
    
    return res.status(200).json({
      success: true,
      message: `Jurisdiction set to ${jurisdictionData.name}`,
      jurisdiction: jurisdictionData,
    });
  } catch (error) {
    console.error('Set jurisdiction error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while setting jurisdiction',
    });
  }
};

// Get jurisdiction-specific settings
const getJurisdictionSettings = async (req, res) => {
  try {
    const jurisdictionCode = req.params.code;
    
    // Check if jurisdiction exists
    const { data: jurisdiction, error: jurisdictionError } = await supabase
      .from('jurisdictions')
      .select('*')
      .eq('code', jurisdictionCode)
      .single();
      
    if (jurisdictionError || !jurisdiction) {
      return res.status(404).json({
        error: true,
        message: 'Jurisdiction not found',
      });
    }
    
    // Get jurisdiction settings
    const { data: settings, error: settingsError } = await supabase
      .from('jurisdiction_settings')
      .select('*')
      .eq('jurisdiction_code', jurisdictionCode);
      
    if (settingsError) {
      throw settingsError;
    }
    
    // Get legal sources for jurisdiction
    const { data: legalSources, error: sourcesError } = await supabase
      .from('legal_sources')
      .select('*')
      .eq('jurisdiction_code', jurisdictionCode);
      
    if (sourcesError) {
      throw sourcesError;
    }
    
    return res.status(200).json({
      success: true,
      jurisdiction,
      settings: settings || [],
      legal_sources: legalSources || [],
    });
  } catch (error) {
    console.error('Get jurisdiction settings error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching jurisdiction settings',
    });
  }
};

module.exports = {
  getJurisdictions,
  getCurrentJurisdiction,
  setJurisdiction,
  getJurisdictionSettings,
};
