const supabase = require('../utils/supabase');
const openaiService = require('../services/openaiService');
const { v4: uuidv4 } = require('uuid');

// Get all chat conversations for a user
const getConversations = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get conversations from Supabase
    const { data, error } = await supabase
      .from('conversations')
      .select('*, messages:messages(id, content, role, created_at)')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });
      
    if (error) {
      throw error;
    }
    
    return res.status(200).json({
      success: true,
      conversations: data || [],
    });
  } catch (error) {
    console.error('Get conversations error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching conversations',
    });
  }
};

// Get a specific chat conversation
const getConversation = async (req, res) => {
  try {
    const userId = req.user.id;
    const conversationId = req.params.id;
    
    // Get conversation from Supabase
    const { data: conversation, error: conversationError } = await supabase
      .from('conversations')
      .select('*')
      .eq('id', conversationId)
      .eq('user_id', userId)
      .single();
      
    if (conversationError) {
      throw conversationError;
    }
    
    if (!conversation) {
      return res.status(404).json({
        error: true,
        message: 'Conversation not found',
      });
    }
    
    // Get messages for the conversation
    const { data: messages, error: messagesError } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });
      
    if (messagesError) {
      throw messagesError;
    }
    
    // Get documents for the conversation
    const { data: documents, error: documentsError } = await supabase
      .from('conversation_documents')
      .select('*')
      .eq('conversation_id', conversationId);
      
    if (documentsError) {
      throw documentsError;
    }
    
    return res.status(200).json({
      success: true,
      conversation: {
        ...conversation,
        messages: messages || [],
        documents: documents || [],
      },
    });
  } catch (error) {
    console.error('Get conversation error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while fetching conversation',
    });
  }
};

// Create a new chat conversation
const createConversation = async (req, res) => {
  try {
    const userId = req.user.id;
    const { title, jurisdiction } = req.body;
    
    // Create conversation in Supabase
    const { data, error } = await supabase
      .from('conversations')
      .insert([
        {
          user_id: userId,
          title: title || 'New Conversation',
          jurisdiction: jurisdiction || 'NO',
        }
      ])
      .select();
      
    if (error) {
      throw error;
    }
    
    // Add system message to set the context
    const systemMessage = getSystemPrompt(jurisdiction || 'NO');
    
    await supabase
      .from('messages')
      .insert([
        {
          conversation_id: data[0].id,
          role: 'system',
          content: systemMessage,
        }
      ]);
    
    return res.status(201).json({
      success: true,
      message: 'Conversation created successfully',
      conversation: data[0],
    });
  } catch (error) {
    console.error('Create conversation error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while creating conversation',
    });
  }
};

// Send a message in a conversation
const sendMessage = async (req, res) => {
  try {
    const userId = req.user.id;
    const conversationId = req.params.id;
    const { content } = req.body;
    
    if (!content) {
      return res.status(400).json({ error: true, message: 'Message content is required' });
    }
    
    // Check if conversation exists and belongs to user
    const { data: conversation, error: conversationError } = await supabase
      .from('conversations')
      .select('*')
      .eq('id', conversationId)
      .eq('user_id', userId)
      .single();
      
    if (conversationError || !conversation) {
      return res.status(404).json({
        error: true,
        message: 'Conversation not found',
      });
    }
    
    // Check if user has enough tokens
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('tokens')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      throw profileError;
    }
    
    if (profile.tokens < 1) {
      return res.status(403).json({
        error: true,
        message: 'Not enough tokens to send message',
      });
    }
    
    // Add user message to database
    const { data: userMessage, error: userMessageError } = await supabase
      .from('messages')
      .insert([
        {
          conversation_id: conversationId,
          role: 'user',
          content,
        }
      ])
      .select();
      
    if (userMessageError) {
      throw userMessageError;
    }
    
    // Get conversation history
    const { data: messages, error: messagesError } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });
      
    if (messagesError) {
      throw messagesError;
    }
    
    // Format messages for OpenAI
    const formattedMessages = messages.map(msg => ({
      role: msg.role,
      content: msg.content,
    }));
    
    // Get AI response
    const aiResponse = await openaiService.getChatCompletion(formattedMessages, conversation.jurisdiction);
    
    // Add AI response to database
    const { data: assistantMessage, error: assistantMessageError } = await supabase
      .from('messages')
      .insert([
        {
          conversation_id: conversationId,
          role: 'assistant',
          content: aiResponse,
        }
      ])
      .select();
      
    if (assistantMessageError) {
      throw assistantMessageError;
    }
    
    // Update conversation timestamp
    await supabase
      .from('conversations')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', conversationId);
    
    // Deduct tokens from user
    await supabase
      .from('profiles')
      .update({ tokens: profile.tokens - 1 })
      .eq('id', userId);
    
    // Record token usage
    await supabase
      .from('token_transactions')
      .insert([
        {
          user_id: userId,
          amount: 1,
          transaction_type: 'usage',
          description: 'Chat message',
          reference_id: conversationId,
        }
      ]);
    
    return res.status(200).json({
      success: true,
      messages: [userMessage[0], assistantMessage[0]],
    });
  } catch (error) {
    console.error('Send message error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while sending message',
    });
  }
};

// Upload a document to a conversation
const uploadDocument = async (req, res) => {
  try {
    const userId = req.user.id;
    const conversationId = req.params.id;
    const { file } = req.files;
    
    if (!file) {
      return res.status(400).json({ error: true, message: 'File is required' });
    }
    
    // Check if conversation exists and belongs to user
    const { data: conversation, error: conversationError } = await supabase
      .from('conversations')
      .select('*')
      .eq('id', conversationId)
      .eq('user_id', userId)
      .single();
      
    if (conversationError || !conversation) {
      return res.status(404).json({
        error: true,
        message: 'Conversation not found',
      });
    }
    
    // Generate unique filename
    const fileExt = file.name.split('.').pop();
    const fileName = `${uuidv4()}.${fileExt}`;
    const filePath = `documents/${userId}/${fileName}`;
    
    // Upload file to Supabase Storage
    const { data: storageData, error: storageError } = await supabase
      .storage
      .from('conversation-documents')
      .upload(filePath, file.data, {
        contentType: file.mimetype,
      });
      
    if (storageError) {
      throw storageError;
    }
    
    // Get public URL
    const { data: urlData } = await supabase
      .storage
      .from('conversation-documents')
      .getPublicUrl(filePath);
    
    // Add document record to database
    const { data: document, error: documentError } = await supabase
      .from('conversation_documents')
      .insert([
        {
          conversation_id: conversationId,
          file_name: file.name,
          file_type: file.mimetype,
          file_size: file.size,
          file_path: filePath,
          public_url: urlData.publicUrl,
        }
      ])
      .select();
      
    if (documentError) {
      throw documentError;
    }
    
    // Add system message about the document
    await supabase
      .from('messages')
      .insert([
        {
          conversation_id: conversationId,
          role: 'system',
          content: `Document uploaded: ${file.name}`,
        }
      ]);
    
    // Update conversation timestamp
    await supabase
      .from('conversations')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', conversationId);
    
    return res.status(200).json({
      success: true,
      message: 'Document uploaded successfully',
      document: document[0],
    });
  } catch (error) {
    console.error('Upload document error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while uploading document',
    });
  }
};

// Delete a conversation
const deleteConversation = async (req, res) => {
  try {
    const userId = req.user.id;
    const conversationId = req.params.id;
    
    // Check if conversation exists and belongs to user
    const { data: conversation, error: conversationError } = await supabase
      .from('conversations')
      .select('*')
      .eq('id', conversationId)
      .eq('user_id', userId)
      .single();
      
    if (conversationError || !conversation) {
      return res.status(404).json({
        error: true,
        message: 'Conversation not found',
      });
    }
    
    // Delete messages
    await supabase
      .from('messages')
      .delete()
      .eq('conversation_id', conversationId);
    
    // Delete documents
    const { data: documents } = await supabase
      .from('conversation_documents')
      .select('file_path')
      .eq('conversation_id', conversationId);
    
    if (documents && documents.length > 0) {
      // Delete files from storage
      for (const doc of documents) {
        await supabase
          .storage
          .from('conversation-documents')
          .remove([doc.file_path]);
      }
      
      // Delete document records
      await supabase
        .from('conversation_documents')
        .delete()
        .eq('conversation_id', conversationId);
    }
    
    // Delete conversation
    await supabase
      .from('conversations')
      .delete()
      .eq('id', conversationId);
    
    return res.status(200).json({
      success: true,
      message: 'Conversation deleted successfully',
    });
  } catch (error) {
    console.error('Delete conversation error:', error);
    return res.status(500).json({
      error: true,
      message: error.message || 'An error occurred while deleting conversation',
    });
  }
};

// Helper function to get system prompt based on jurisdiction
const getSystemPrompt = (jurisdiction) => {
  const basePrompt = "You are KAI, an AI legal assistant. You provide helpful, accurate, and ethical legal information. Remember that you are not a licensed attorney and should advise users to consult with a qualified legal professional for specific legal advice.";
  
  switch (jurisdiction) {
    case 'NO':
      return `${basePrompt} You specialize in Norwegian law and legal system. Your knowledge includes Norwegian civil law, criminal law, administrative law, and procedural law.`;
    case 'SE':
      return `${basePrompt} You specialize in Swedish law and legal system. Your knowledge includes Swedish civil law, criminal law, administrative law, and procedural law.`;
    case 'DK':
      return `${basePrompt} You specialize in Danish law and legal system. Your knowledge includes Danish civil law, criminal law, administrative law, and procedural law.`;
    case 'EU':
      return `${basePrompt} You specialize in EU law and international legal frameworks. Your knowledge includes EU regulations, directives, decisions, and international treaties.`;
    default:
      return basePrompt;
  }
};

module.exports = {
  getConversations,
  getConversation,
  createConversation,
  sendMessage,
  uploadDocument,
  deleteConversation,
};
